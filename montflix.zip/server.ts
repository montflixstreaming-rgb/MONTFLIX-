import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import axios from "axios";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());
  app.use(cors());

  // API Routes
  app.post("/api/payment/pix", async (req, res) => {
    const { amount, planName, userEmail } = req.body;
    const apiKey = process.env.EVOPAY_API_KEY || "9dbb2062-a7e0-4208-b430-c3f9e10a18a8";
    const userApiUrl = process.env.EVOPAY_API_URL || "https://api.evopay.com.br/v1";
    const fallbackApiUrl = "https://api.evopay.cash/v1";
    const webhookUrl = process.env.EVOPAY_WEBHOOK_URL || `${process.env.APP_URL || "https://montflix-pro.vercel.app"}/api/payment/webhook`;

    const tryRequest = async (baseUrl: string) => {
      const cleanBaseUrl = baseUrl.replace(/\/$/, "");
      const endpoints = [
        cleanBaseUrl.endsWith("/pix") ? cleanBaseUrl : `${cleanBaseUrl}/pix`,
        "https://pix.evopay.cash/v1/pix",
        "https://api.evopay.cash/v1/pix"
      ].filter((v, i, a) => v.length > 10 && a.indexOf(v) === i);

      const authHeaders = [
        { "API-Key": apiKey },
        { "Authorization": `Bearer ${apiKey}` },
        { "x-api-key": apiKey },
        { "token": apiKey }
      ];

      const amountNum = Number(amount);
      if (isNaN(amountNum)) throw new Error("Preço inválido enviado para o servidor.");
      const amounts = [amountNum, Math.round(amountNum * 100)];

      let lastError;
      for (const endpoint of endpoints) {
        for (const headers of authHeaders) {
          for (const currentAmount of amounts) {
            try {
              const payload = {
                amount: currentAmount,
                description: `Assinatura Montflix - ${planName}`,
                external_id: `mf_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
                callbackUrl: webhookUrl
              };
              
              console.log(`Attempting real EvoPay call to: ${endpoint} | Header: ${Object.keys(headers)[0]} | Amount: ${currentAmount} (${typeof currentAmount})`);
              
              const res = await axios.post(endpoint, payload, {
                headers: {
                  ...headers,
                  "Content-Type": "application/json"
                },
                timeout: 8000
              });
              
              console.log(`Success with: ${endpoint} | Header: ${Object.keys(headers)[0]} | Amount: ${currentAmount}`);
              return res;
            } catch (err: any) {
              lastError = err;
              const status = err.response?.status;
              const errorData = err.response?.data;
              
              console.warn(`Failed: ${endpoint} | Header: ${Object.keys(headers)[0]} | Amount: ${currentAmount} | Status: ${status} | Error:`, JSON.stringify(errorData || err.message));
              
              if (status === 401) continue;
              if (status === 404) break;
              continue;
            }
          }
        }
      }
      throw lastError;
    };

    try {
      let response;
      try {
        response = await tryRequest(userApiUrl);
      } catch (err: any) {
        if (err.code === 'ENOTFOUND' || err.code === 'ECONNREFUSED' || err.code === 'ETIMEDOUT' || err.response?.status === 404) {
          console.warn(`Primary API URL/Endpoints failed, trying fallback: ${fallbackApiUrl}`);
          response = await tryRequest(fallbackApiUrl);
        } else {
          throw err;
        }
      }

      console.log("EvoPay API Response:", JSON.stringify(response.data, null, 2));

      // Robustly find the transaction ID and QR Code/BRCode in the response
      const findField = (obj: any, keys: string[]): any => {
        if (!obj || typeof obj !== 'object') return null;
        for (const key of keys) {
          if (obj[key]) return obj[key];
        }
        for (const key in obj) {
          if (typeof obj[key] === 'object' && obj[key] !== null) {
            const found = findField(obj[key], keys);
            if (found) return found;
          }
        }
        return null;
      };

      const transactionId = findField(response.data, ['id', 'transaction_id', 'external_id', 'transactionId', 'uuid', 'payment_id']);
      const brCode = findField(response.data, ['qrcode', 'pix_code', 'brcode', 'copy_paste', 'qrcode_text', 'emv', 'pix_copy_paste', 'payload', 'pix_payload', 'code', 'qrCodeText', 'qrCodeUrl']);
      
      // The user mentioned this URL format: https://pix.evopay.cash/v1/plx?id=TRANSACTION ID
      const paymentUrl = transactionId ? `https://pix.evopay.cash/v1/plx?id=${transactionId}` : null;

      if (!transactionId && !brCode) {
        throw new Error("A API da EvoPay respondeu com sucesso, mas não retornou um ID de transação ou código PIX válido.");
      }

      res.json({
        success: true,
        qrcode: findField(response.data, ['qrCodeUrl', 'qrcode_url', 'url']) || `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(brCode || paymentUrl || "")}`,
        qrcode_text: brCode || paymentUrl,
        payment_id: transactionId
      });
    } catch (error: any) {
      console.error("EvoPay Error:", error.response?.data || error.message);
      
      // Fallback for demo/dev if API fails or endpoint is slightly different
      // In a real scenario, we want to show the error or a fallback.
      res.status(500).json({ 
        success: false, 
        error: "Erro ao gerar PIX. Verifique sua chave de API.",
        details: error.response?.data
      });
    }
  });

  // Webhook for payment confirmation (optional but good for real apps)
  app.post("/api/payment/webhook", (req, res) => {
    const payload = req.body;
    console.log("Payment Webhook received:", payload);
    // Here you would update the user's plan in a database
    res.sendStatus(200);
  });

  // Status check endpoint
  app.get("/api/payment/status", async (req, res) => {
    const { id } = req.query;
    const apiKey = process.env.EVOPAY_API_KEY || "9dbb2062-a7e0-4208-b430-c3f9e10a18a8";
    const userApiUrl = process.env.EVOPAY_API_URL || "https://api.evopay.com.br/v1";
    const fallbackApiUrl = "https://api.evopay.cash/v1";

    if (!id) return res.status(400).json({ error: "ID is required" });

    const tryStatus = async (baseUrl: string) => {
      const cleanBaseUrl = baseUrl.replace(/\/$/, "");
      return await axios.get(`${cleanBaseUrl}/pix?id=${id}`, {
        headers: { "API-Key": apiKey },
        timeout: 5000
      });
    };

    try {
      let response;
      try {
        response = await tryStatus(userApiUrl);
      } catch (err) {
        response = await tryStatus(fallbackApiUrl);
      }
      res.json(response.data);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*all', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
