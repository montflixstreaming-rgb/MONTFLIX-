
/**
 * TMDB SERVICE v2.5 - MONTFLIX ULTRA SPEED
 * Chave Pessoal: d5ece792587135e1e07bc5ae8be84538
 */

const API_KEY = 'd5ece792587135e1e07bc5ae8be84538'; 
const BASE_URL = 'https://api.themoviedb.org/3';
const CACHE_KEY = 'montflix_catalog_cache_v2';

export const tmdbService = {
  /**
   * Recupera o catálogo salvo para exibição INSTANTÂNEA
   */
  getCachedData() {
    try {
      const cached = localStorage.getItem(CACHE_KEY);
      return cached ? JSON.parse(cached) : null;
    } catch {
      return null;
    }
  },

  /**
   * Persiste o catálogo em background
   */
  setCacheData(data: any) {
    try {
      localStorage.setItem(CACHE_KEY, JSON.stringify(data));
    } catch (e) {
      console.warn("Cache storage full");
    }
  },

  /**
   * Busca otimizada sem telas de carregamento
   */
  async fetchMovies(endpoint: string, page = 1) {
    try {
      const separator = endpoint.includes('?') ? '&' : '?';
      const url = `${BASE_URL}${endpoint}${separator}api_key=${API_KEY}&language=pt-BR&page=${page}&include_adult=false`;
      
      const response = await fetch(url);
      if (!response.ok) return [];

      const data = await response.json();
      return data.results ? data.results.map((m: any) => this.formatMovie(m)) : [];
    } catch (error) {
      console.error("TMDB Fetch Error:", error);
      return [];
    }
  },

  async getTrending(page = 1) { return this.fetchMovies('/trending/movie/day', page); },
  async getPopular(page = 1) { return this.fetchMovies('/movie/popular', page); },
  async getNowPlaying(page = 1) { return this.fetchMovies('/movie/now_playing', page); },
  async getUpcoming(page = 1) { return this.fetchMovies('/movie/upcoming', page); },
  async getTopRated(page = 1) { return this.fetchMovies('/movie/top_rated', page); },
  
  async discoverByGenre(genreId: number, page = 1) {
    return this.fetchMovies(`/discover/movie?with_genres=${genreId}&sort_by=popularity.desc`, page);
  },

  async search(query: string, page = 1) {
    if (!query || query.trim().length < 2) return [];
    return this.fetchMovies(`/search/movie?query=${encodeURIComponent(query.trim())}`, page);
  },

  /**
   * Busca o trailer oficial do filme (PT-BR primeiro, depois EN-US)
   */
  async getMovieTrailer(movieId: string): Promise<string | null> {
    try {
      // 1. Tentar buscar em português
      let url = `${BASE_URL}/movie/${movieId}/videos?api_key=${API_KEY}&language=pt-BR`;
      let response = await fetch(url);
      let data = await response.json();
      let videos = data.results || [];

      // 2. Se não houver vídeos em PT-BR, buscar em inglês
      if (videos.length === 0) {
        url = `${BASE_URL}/movie/${movieId}/videos?api_key=${API_KEY}&language=en-US`;
        response = await fetch(url);
        data = await response.json();
        videos = data.results || [];
      }

      // 3. Procurar pelo trailer oficial do YouTube
      let trailer = videos.find((v: any) => v.site === 'YouTube' && v.type === 'Trailer');
      
      // 4. Se não achar do tipo "Trailer", pegar qualquer vídeo oficial do YouTube
      if (!trailer) {
        trailer = videos.find((v: any) => v.site === 'YouTube' && (v.type === 'Teaser' || v.type === 'Clip'));
      }
      
      if (!trailer && videos.length > 0) {
        trailer = videos.find((v: any) => v.site === 'YouTube');
      }

      if (trailer && trailer.key) {
        return `https://www.youtube.com/embed/${trailer.key}?autoplay=1&mute=0&controls=1&showinfo=0&rel=0&modestbranding=1&autoplay=1`;
      }
      
      return null;
    } catch (error) {
      console.error("TMDB getMovieTrailer error:", error);
      return null;
    }
  },

  /**
   * Busca múltiplas páginas em paralelo para enriquecer o catálogo
   */
  async fetchMultiPages(fetchFn: (page: number) => Promise<any[]>, numPages = 4) {
    try {
      const promises = [];
      for (let p = 1; p <= numPages; p++) {
        promises.push(fetchFn(p));
      }
      const results = await Promise.all(promises);
      return results.flat().filter((v, i, a) => a.findIndex(t => t.id === v.id) === i);
    } catch (e) {
      console.error("Multi page fetch error:", e);
      return fetchFn(1);
    }
  },

  /**
   * Formata os dados reais do TMDB com suporte a imagens originais
   */
  formatMovie(m: any) {
    return {
      id: String(m.id),
      title: m.title || m.original_title || 'Título Indisponível',
      posterUrl: m.poster_path 
        ? `https://image.tmdb.org/t/p/w500${m.poster_path}` 
        : 'https://images.unsplash.com/photo-1594908900066-3f47337549d8?q=80&w=500&auto=format&fit=crop',
      backdropUrl: m.backdrop_path 
        ? `https://image.tmdb.org/t/p/original${m.backdrop_path}` 
        : 'https://images.unsplash.com/photo-1485846234645-a62644f84728?q=80&w=1280&auto=format&fit=crop',
      rating: m.vote_average || 0,
      year: m.release_date ? new Date(m.release_date).getFullYear() : 2025,
      description: m.overview || 'Sinopse oficial em processamento pela nossa equipe de tradução.',
      category: 'Cinema',
      videoUrl: 'AUTO_EMBED' // O VideoPlayer usará o ID para o CineGato
    };
  }
};
