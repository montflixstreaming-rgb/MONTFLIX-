import React, { useRef, useMemo, useState } from 'react';
import { Language } from '../translations';
import { User, ShieldCheck, Mail, CreditCard, Award, Flame, LogOut, Check, Image as ImageIcon, Tv, CheckCircle2, Laptop, Smartphone, Gamepad2, Trash2, Globe, History, AlertTriangle } from 'lucide-react';
import { Security } from '../services/security';

interface UserRecord {
  id: string;
  email: string;
  name: string;
  avatar: string | null;
  createdAt: string;
  lastLogin: string;
  xp?: number;
  plan?: 'essencial' | 'padrao' | 'premium';
  cpf?: string;
}

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserRecord;
  onUpdateAvatar: (newAvatar: string) => void;
  onLogout: () => void;
  currentLang: Language;
  setLanguage: (lang: Language) => void;
  onShowToast: (msg: string) => void;
  onSwitchProfile?: () => void;
}

// Lista de Avatares Predefinidos de Cinema (Estilo Netflix)
const PRESET_AVATARS = [
  { name: 'Felix', url: 'https://api.dicebear.com/7.x/pixel-art/svg?seed=Felix' },
  { name: 'Ane', url: 'https://api.dicebear.com/7.x/pixel-art/svg?seed=Ane' },
  { name: 'Jack', url: 'https://api.dicebear.com/7.x/pixel-art/svg?seed=Jack' },
  { name: 'Mimi', url: 'https://api.dicebear.com/7.x/pixel-art/svg?seed=Mimi' },
  { name: 'Zoe', url: 'https://api.dicebear.com/7.x/pixel-art/svg?seed=Zoe' },
  { name: 'Leo', url: 'https://api.dicebear.com/7.x/pixel-art/svg?seed=Leo' },
  { name: 'Maya', url: 'https://api.dicebear.com/7.x/pixel-art/svg?seed=Maya' },
  { name: 'Toby', url: 'https://api.dicebear.com/7.x/pixel-art/svg?seed=Toby' }
];

const SettingsModal: React.FC<SettingsModalProps> = ({ 
  isOpen, onClose, user, onUpdateAvatar, onLogout, onShowToast, onSwitchProfile
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [activeTab, setActiveTab] = useState<'profile' | 'plan' | 'pairing'>('profile');
  
  // Pairing Code States
  const [pairCode, setPairCode] = useState('');
  const [isPairingInProgress, setIsPairingInProgress] = useState(false);
  const [pairingMessage, setPairingMessage] = useState<string | null>(null);
  const [pairingSuccess, setPairingSuccess] = useState(false);
  const [foundRequest, setFoundRequest] = useState<{ code: string; type: string; name: string; createdAt: string } | null>(null);

  // Seed default active device (current session) if none exists, and retrieve lists
  const activeDevices = useMemo(() => {
    const listKey = `montflix_active_devices_${user.email.toLowerCase().trim()}`;
    const activeDevicesEnc = localStorage.getItem(listKey);
    let devices = [];
    if (activeDevicesEnc) {
      try {
        devices = Security.decrypt(activeDevicesEnc) || [];
      } catch (err) {
        console.error("Erro ao decodificar dispositivos ativos:", err);
      }
    } else {
      const currentDevice = {
        id: 'current-session-id',
        code: 'SESSAO',
        name: 'Este Smartphone (Atual)',
        type: 'mobile',
        activatedAt: new Date(Date.now() - 3600000 * 24 * 3).toISOString(), // 3 dias atrás
        ip: "177.89.201.42",
        city: "Rio de Janeiro, RJ"
      };
      devices = [currentDevice];
      localStorage.setItem(listKey, Security.encrypt(devices));
    }
    // Referenciar pairingSuccess para atualizar a lista ao conectar/revogar aparelhos
    if (pairingSuccess) {
      // Sem ação, apenas dependência ativa
    }
    return devices;
  }, [user.email, pairingSuccess]);

  const handleLookupRequest = () => {
    const cleanCode = pairCode.trim().toUpperCase();
    if (cleanCode.length !== 6) {
      onShowToast("O código de pareamento deve conter exatamente 6 dígitos.");
      return;
    }
    
    setIsPairingInProgress(true);
    setPairingMessage(null);
    setFoundRequest(null);
    
    setTimeout(() => {
      const reqEnc = localStorage.getItem(`montflix_pair_req_${cleanCode}`);
      setIsPairingInProgress(false);
      
      if (reqEnc) {
        try {
          const reqDec = Security.decrypt(reqEnc);
          if (reqDec && reqDec.code === cleanCode) {
            setFoundRequest(reqDec);
            setPairingMessage(null);
          } else {
            setPairingMessage("Código inválido ou já expirou.");
          }
        } catch (e) {
          setPairingMessage("Falha ao descriptografar requisição.");
        }
      } else {
        setPairingMessage("Código de pareamento não encontrado ou já expirou.");
      }
    }, 1000);
  };

  const handleAuthorizePairing = () => {
    if (!foundRequest) return;
    
    setIsPairingInProgress(true);
    setPairingMessage(null);
    
    setTimeout(() => {
      try {
        const encryptedUser = Security.encrypt(user);
        // Grava as credenciais criptografadas para o polling do outro aparelho liberar o login
        localStorage.setItem(`montflix_pair_${foundRequest.code}`, encryptedUser);
        
        // Adiciona à lista de dispositivos ativos da conta
        const listKey = `montflix_active_devices_${user.email.toLowerCase().trim()}`;
        const activeDevicesEnc = localStorage.getItem(listKey);
        let devicesList = [];
        if (activeDevicesEnc) {
          try {
            devicesList = Security.decrypt(activeDevicesEnc) || [];
          } catch (err) {
            console.error("Erro ao descriptografar dispositivos:", err);
          }
        }
        
        const newDevice = {
          id: crypto.randomUUID(),
          code: foundRequest.code,
          name: foundRequest.name,
          type: foundRequest.type,
          activatedAt: new Date().toISOString(),
          ip: "189.32.14." + Math.floor(Math.random() * 255), // IP simulado
          city: "São Paulo, SP", // Cidade simulada
        };
        
        devicesList.push(newDevice);
        localStorage.setItem(listKey, Security.encrypt(devicesList));
        
        setPairingSuccess(true);
        setIsPairingInProgress(false);
        setPairingMessage(`Aparelho "${foundRequest.name}" ativado com sucesso! Ele foi logado instantaneamente na sua conta de forma dividida.`);
        onShowToast("Aparelho Ativado com Sucesso!");
        
        // Limpar request do storage
        localStorage.removeItem(`montflix_pair_req_${foundRequest.code}`);
        
        setFoundRequest(null);
        setPairCode('');
        
        setTimeout(() => {
          setPairingSuccess(false);
          setPairingMessage(null);
        }, 5000);
      } catch (err) {
        setIsPairingInProgress(false);
        setPairingMessage("Falha ao autorizar pareamento. Tente novamente.");
        onShowToast("Falha na Autorização");
      }
    }, 1200);
  };

  const handleRevokeDevice = (deviceId: string, deviceName: string) => {
    if (confirm(`Deseja realmente revogar o acesso do aparelho "${deviceName}"? Ele perderá a conexão imediatamente.`)) {
      const listKey = `montflix_active_devices_${user.email.toLowerCase().trim()}`;
      const activeDevicesEnc = localStorage.getItem(listKey);
      if (activeDevicesEnc) {
        try {
          const list = Security.decrypt(activeDevicesEnc) || [];
          const updatedList = list.filter((d: any) => d.id !== deviceId);
          localStorage.setItem(listKey, Security.encrypt(updatedList));
          onShowToast(`Acesso revogado para: ${deviceName}`);
          
          // Dispara um re-render do memo
          setPairingSuccess(prev => !prev);
          setTimeout(() => setPairingSuccess(false), 50);
        } catch (e) {
          console.error("Erro ao revogar aparelho:", e);
        }
      }
    }
  };

  const fanStats = useMemo(() => {
    const xp = user.xp || 150; 
    let level = "Espectador Bronze";
    let color = "#CD7F32";
    let progress = (xp % 100);
    let nextLevelXp = 300;
    
    if (xp > 1000) { 
      level = "Lenda do Cinema"; 
      color = "#FFD700"; 
      progress = 100;
      nextLevelXp = 1000;
    } else if (xp > 600) { 
      level = "Mestre Platina"; 
      color = "#E5E4E2"; 
      progress = ((xp - 600) / 400) * 100;
      nextLevelXp = 1000;
    } else if (xp > 300) { 
      level = "Cineasta Ouro"; 
      color = "#FFD700"; 
      progress = ((xp - 300) / 300) * 100;
      nextLevelXp = 600;
    } else if (xp > 100) { 
      level = "Crítico Prata"; 
      color = "#C0C0C0"; 
      progress = ((xp - 100) / 200) * 100;
      nextLevelXp = 300;
    }

    return { level, color, progress, xp, nextLevelXp };
  }, [user.xp]);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onUpdateAvatar(reader.result as string);
        onShowToast("Avatar atualizado com sucesso!");
      };
      reader.readAsDataURL(file);
    }
  };

  const selectPresetAvatar = (url: string) => {
    onUpdateAvatar(url);
    onShowToast("Visual do perfil alterado!");
  };

  // Obter detalhes elegantes sobre o plano ativo
  const getPlanDescription = () => {
    const p = user.plan || 'premium';
    switch (p) {
      case 'essencial':
        return {
          title: 'Plano Essencial',
          badge: 'HD COM ANÚNCIOS',
          color: 'text-zinc-400 border-zinc-500 bg-zinc-900/50',
          benefits: ['Qualidade HD (720p)', 'Anúncios pontuais', 'Canais de TV SD/HD', 'Suporte standard']
        };
      case 'padrao':
        return {
          title: 'Plano Padrão',
          badge: 'FULL HD • SEM ANÚNCIOS',
          color: 'text-cyan-400 border-cyan-500 bg-cyan-950/20',
          benefits: ['Qualidade Full HD (1080p)', '100% Livre de anúncios', 'Todos os Canais de TV HD', '2 Telas Simultâneas', 'Áudio Stereo Premium']
        };
      case 'premium':
      default:
        return {
          title: 'Plano Ultra Premium 4K',
          badge: '4K ULTRA HD + HDR',
          color: 'text-[#00D1FF] border-[#00D1FF]/30 bg-[#00D1FF]/10',
          glow: 'shadow-[0_0_20px_rgba(0,209,255,0.25)]',
          benefits: ['Qualidade 4K Ultra HD & HDR', 'Sem anúncios, diversão pura', 'Canais IPTV Premium em 4K/60fps', '4 Telas Simultâneas', 'Som Dolby Atmos Surround', 'Suporte Técnico VIP 24h']
        };
    }
  };

  const planDetails = getPlanDescription();

  return (
    <div className="fixed inset-0 z-[400] flex items-center justify-center p-0 sm:p-4 md:p-6 overflow-y-auto animate-in fade-in duration-300">
      {/* Backdrop de Desfocagem Premium */}
      <div className="absolute inset-0 bg-black/95 backdrop-blur-3xl" onClick={onClose} />
      
      {/* Container Principal */}
      <div className="relative w-full h-full sm:h-auto sm:max-w-[600px] bg-zinc-950 text-white sm:rounded-3xl border border-white/10 flex flex-col overflow-hidden shadow-[0_0_50px_rgba(0,209,255,0.15)] animate-in zoom-in-95 duration-300">
        
        {/* HEADER DO PERFIL */}
        <div className="flex items-center justify-between px-8 py-6 border-b border-white/5 bg-zinc-900/30">
          <div>
            <h2 className="text-xs font-black uppercase tracking-[0.4em] text-[#00D1FF]">MONTFLIX PROFILE</h2>
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mt-1">Sua Conta & Patente de Cinema</p>
          </div>
          <button 
            onClick={onClose} 
            className="w-10 h-10 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 hover:border-white/20 flex items-center justify-center text-white text-sm transition-all active:scale-95 duration-200"
          >
            ✕
          </button>
        </div>

        {/* SUB-MENU TABS */}
        <div className="flex border-b border-white/5 bg-zinc-900/15">
          <button
            onClick={() => setActiveTab('profile')}
            className={`flex-1 py-4 text-xs font-black uppercase tracking-wider text-center border-b-2 transition-all ${
              activeTab === 'profile'
                ? 'border-[#00D1FF] text-white bg-white/[0.02]'
                : 'border-transparent text-gray-500 hover:text-gray-300'
            }`}
          >
            👤 Meu Perfil
          </button>
          <button
            onClick={() => setActiveTab('plan')}
            className={`flex-1 py-4 text-xs font-black uppercase tracking-wider text-center border-b-2 transition-all ${
              activeTab === 'plan'
                ? 'border-[#00D1FF] text-white bg-white/[0.02]'
                : 'border-transparent text-gray-500 hover:text-gray-300'
            }`}
          >
            💳 Plano Ativo
          </button>
          <button
            onClick={() => setActiveTab('pairing')}
            className={`flex-1 py-4 text-xs font-black uppercase tracking-wider text-center border-b-2 transition-all ${
              activeTab === 'pairing'
                ? 'border-[#00D1FF] text-white bg-white/[0.02]'
                : 'border-transparent text-gray-500 hover:text-gray-300'
            }`}
          >
            📺 Ativar Aparelho
          </button>
        </div>

        {/* CORPO DO MODAL */}
        <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-8 max-h-[70vh] scrollbar-thin">
          
          {activeTab === 'profile' ? (
            <>
              {/* CARD DE INFORMAÇÕES PESSOAIS */}
              <div className="bg-gradient-to-br from-white/[0.02] to-transparent p-6 rounded-3xl border border-white/5 space-y-6">
                
                {/* Visual e Identificação */}
                <div className="flex flex-col sm:flex-row items-center gap-6">
                  <div className="relative shrink-0 group">
                    <div className="w-24 h-24 rounded-2xl bg-zinc-900 flex items-center justify-center overflow-hidden ring-4 ring-[#00D1FF]/20 shadow-2xl relative">
                      {user.avatar ? (
                        <img src={user.avatar} className="w-full h-full object-cover" alt="Avatar" />
                      ) : (
                        <div className="text-white/40 text-4xl"><User size={40} /></div>
                      )}
                      
                      {/* Upload de arquivo manual */}
                      <button 
                        onClick={() => fileInputRef.current?.click()}
                        className="absolute inset-0 bg-black/70 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center transition-all duration-300 cursor-pointer"
                      >
                        <ImageIcon size={18} className="text-[#00D1FF] mb-1" />
                        <span className="text-[8px] font-black uppercase text-white tracking-widest">Upload</span>
                      </button>
                    </div>
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileUpload} />
                  </div>

                  <div className="text-center sm:text-left space-y-2 min-w-0 flex-1">
                    <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#00D1FF]/10 border border-[#00D1FF]/20 rounded-full text-[9px] font-black text-[#00D1FF] uppercase tracking-wider">
                      <ShieldCheck size={10} /> Conta Protegida
                    </div>
                    <h3 className="text-2xl font-black tracking-tight text-white truncate">
                      {user.name || 'Assinante Montflix'}
                    </h3>
                    <p className="text-xs text-white/50 font-medium truncate flex items-center justify-center sm:justify-start gap-1.5">
                      <Mail size={12} className="text-[#00D1FF]" /> {user.email}
                    </p>
                  </div>
                </div>

                {/* GALERIA INTERATIVA DE AVATARES (ESTILO NETFLIX) */}
                <div className="pt-4 border-t border-white/5 space-y-3">
                  <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest text-center sm:text-left">
                    🎬 Escolha seu Personagem de Perfil
                  </p>
                  <div className="flex flex-wrap justify-center sm:justify-start gap-3">
                    {PRESET_AVATARS.map((av, index) => {
                      const isSelected = user.avatar === av.url;
                      return (
                        <button
                          key={index}
                          onClick={() => selectPresetAvatar(av.url)}
                          className={`w-12 h-12 rounded-xl overflow-hidden border-2 transition-all active:scale-95 shrink-0 hover:scale-105 relative ${
                            isSelected 
                              ? 'border-[#00D1FF] scale-110 shadow-[0_0_15px_rgba(0,209,255,0.4)]' 
                              : 'border-white/10 hover:border-white/30'
                          }`}
                          title={av.name}
                        >
                          <img src={av.url} className="w-full h-full object-cover" alt={av.name} />
                          {isSelected && (
                            <div className="absolute inset-0 bg-[#00D1FF]/30 flex items-center justify-center">
                              <Check size={14} className="text-black stroke-[4px]" />
                            </div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* INFORMAÇÃO CADASTRO ADICIONAL */}
                <div className="pt-4 border-t border-white/5 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-medium text-white/40">
                  <div className="bg-zinc-950 p-3 rounded-xl border border-white/5">
                    <span className="block text-[8px] font-black uppercase text-gray-500 tracking-wider mb-0.5">Nome de Cadastro</span>
                    <span className="text-white text-xs font-bold">{user.name || 'Não informado'}</span>
                  </div>
                  <div className="bg-zinc-950 p-3 rounded-xl border border-white/5">
                    <span className="block text-[8px] font-black uppercase text-gray-500 tracking-wider mb-0.5">CPF Seguro</span>
                    <span className="text-white text-xs font-bold">
                      {user.cpf ? `***.${user.cpf.substring(4, 7)}.***-**` : '***.354.***-**'}
                    </span>
                  </div>
                </div>

              </div>

              {/* SISTEMA DE PATENTE E GAMIFICAÇÃO */}
              <div className="bg-gradient-to-br from-[#00D1FF]/5 to-transparent p-6 rounded-3xl border border-white/5 space-y-4">
                <div className="flex justify-between items-end">
                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5">
                      <Award size={14} className="text-[#00D1FF]" />
                      <p className="text-[10px] font-black text-[#00D1FF] uppercase tracking-widest">Patente Cinefilia</p>
                    </div>
                    <p className="text-lg font-black uppercase tracking-tighter" style={{ color: fanStats.color }}>
                      {fanStats.level}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-[10px] font-mono text-gray-400 font-bold">XP Acumulado</p>
                    <p className="text-sm font-black font-mono text-white">{fanStats.xp} / {fanStats.nextLevelXp} XP</p>
                  </div>
                </div>

                {/* Barra de Progresso Neon */}
                <div className="h-2.5 w-full bg-black/40 rounded-full border border-white/5 overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-[#00D1FF] to-blue-500 shadow-[0_0_15px_rgba(0,209,255,0.4)] transition-all duration-1000"
                    style={{ width: `${fanStats.progress}%` }}
                  />
                </div>
                
                <div className="flex justify-between text-[9px] text-gray-500 font-bold uppercase tracking-widest">
                  <span className="flex items-center gap-1"><Flame size={10} className="text-orange-500 animate-pulse" /> Assistindo diariamente</span>
                  <span>Próxima Patente: +{(fanStats.nextLevelXp - fanStats.xp)} XP</span>
                </div>
              </div>

              {onSwitchProfile && (
                <button
                  onClick={() => {
                    onSwitchProfile();
                    onClose();
                  }}
                  className="w-full flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 text-[#00D1FF] hover:text-white font-black py-4 px-6 rounded-2xl border border-white/5 hover:border-[#00D1FF]/25 text-xs uppercase tracking-wider transition-all"
                >
                  🔄 Trocar Perfil (Mudar Usuário)
                </button>
              )}
            </>
          ) : activeTab === 'plan' ? (
            /* DETALHES DO PLANO */
            <div className="space-y-6">
              
              <div className={`p-6 rounded-3xl border ${planDetails.color} ${planDetails.glow || ''} relative overflow-hidden transition-all duration-500`}>
                <div className="absolute top-0 right-0 w-32 h-32 bg-[#00D1FF]/5 rounded-full blur-2xl" />
                
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <span className="px-2.5 py-1 bg-white/5 border border-white/10 rounded text-[9px] font-black uppercase tracking-wider">
                      Assinatura Ativa
                    </span>
                    <h4 className="text-2xl font-black italic tracking-tighter text-white pt-2">
                      {planDetails.title}
                    </h4>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] font-bold uppercase tracking-widest text-gray-500 block">Investimento</span>
                    <span className="text-xl font-black text-white">R$ {user.plan === 'essencial' ? '20' : user.plan === 'padrao' ? '40' : '60'},00<span className="text-xs text-gray-500 font-bold">/mês</span></span>
                  </div>
                </div>

                {/* Lista de Benefícios ativados */}
                <div className="mt-6 pt-6 border-t border-white/5 space-y-3">
                  <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">
                    Benefícios Inclusos no seu plano:
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {planDetails.benefits.map((b, i) => (
                      <div key={i} className="flex items-center gap-2 text-gray-300">
                        <span className="text-[#00D1FF]">✓</span>
                        <span>{b}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Informações adicionais do plano */}
              <div className="bg-zinc-900/20 border border-white/5 p-6 rounded-2xl space-y-4 text-xs leading-relaxed text-gray-400">
                <div className="flex items-center gap-2 text-[#00D1FF] font-black text-[10px] uppercase tracking-wider">
                  <CreditCard size={14} /> Ciclo de Faturamento
                </div>
                <p>
                  Sua assinatura é renovada automaticamente todo mês. O faturamento é protegido de ponta a ponta. Você pode gerenciar ou atualizar sua assinatura a qualquer momento com nosso suporte de atendimento premium.
                </p>
              </div>

            </div>
          ) : (
            /* PAREAMENTO DE APARELHOS PROFISSIONAL */
            <div className="space-y-6 animate-in fade-in duration-300">
              
              {/* ATIVAR APARELHO */}
              <div className="bg-gradient-to-br from-[#00D1FF]/5 to-transparent p-6 rounded-3xl border border-white/5 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-[#00D1FF]/10 rounded-lg">
                    <Tv className="w-5 h-5 text-[#00D1FF]" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black uppercase tracking-wider text-white">Vincular Novo Dispositivo</h4>
                    <p className="text-[9px] text-gray-500 uppercase tracking-widest font-black">Dividir conta de forma profissional e segura</p>
                  </div>
                </div>

                {!foundRequest ? (
                  <>
                    <p className="text-xs text-white/60 leading-relaxed font-semibold">
                      Para autorizar e compartilhar o acesso do Montflix em outra TV, celular ou videogame, digite o código de 6 caracteres que aparece na tela daquele aparelho.
                    </p>

                    <div className="space-y-3 pt-2">
                      <label className="text-[10px] font-black uppercase tracking-widest text-gray-400 block">
                        Código de Pareamento de 6 Caracteres
                      </label>
                      <div className="flex gap-3">
                        <input
                          type="text"
                          maxLength={6}
                          value={pairCode}
                          onChange={(e) => setPairCode(e.target.value.toUpperCase())}
                          placeholder="EX: BK9X2Y"
                          disabled={isPairingInProgress}
                          className="flex-1 bg-black/60 border border-white/10 rounded-2xl px-5 py-4 text-center text-lg font-black tracking-[0.25em] text-[#00D1FF] placeholder-white/10 focus:outline-none focus:border-[#00D1FF] transition-all animate-pulse"
                        />
                        <button
                          onClick={handleLookupRequest}
                          disabled={isPairingInProgress || pairCode.trim().length !== 6}
                          className="bg-[#00D1FF] hover:bg-[#00D1FF]/90 text-black font-black px-6 rounded-2xl text-xs uppercase tracking-wider transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                        >
                          {isPairingInProgress ? (
                            <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                          ) : 'Verificar'}
                        </button>
                      </div>
                    </div>
                  </>
                ) : (
                  /* Confirmação do Aparelho Encontrado */
                  <div className="p-4 bg-zinc-950/80 border border-[#00D1FF]/20 rounded-2xl space-y-4 animate-in zoom-in-95">
                    <div className="text-center py-2 space-y-1">
                      <span className="px-2 py-0.5 bg-[#00D1FF]/10 border border-[#00D1FF]/30 text-[#00D1FF] rounded text-[8px] font-black uppercase tracking-widest">
                        Aparelho Encontrado!
                      </span>
                      <h5 className="text-sm font-black text-white uppercase tracking-wider pt-2">Deseja autorizar este dispositivo?</h5>
                    </div>

                    <div className="flex items-center gap-4 bg-white/5 p-4 rounded-xl border border-white/5">
                      <div className="p-3 bg-zinc-900 rounded-lg">
                        {foundRequest.type === 'tv' && <Tv className="w-6 h-6 text-[#00D1FF]" />}
                        {foundRequest.type === 'mobile' && <Smartphone className="w-6 h-6 text-[#00D1FF]" />}
                        {foundRequest.type === 'desktop' && <Laptop className="w-6 h-6 text-[#00D1FF]" />}
                        {foundRequest.type === 'console' && <Gamepad2 className="w-6 h-6 text-[#00D1FF]" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-black text-white uppercase truncate">{foundRequest.name}</p>
                        <p className="text-[9px] text-gray-500 uppercase tracking-widest font-bold">
                          Tipo: {foundRequest.type === 'tv' ? 'Smart TV' : foundRequest.type === 'mobile' ? 'Smartphone / Tablet' : foundRequest.type === 'desktop' ? 'Computador' : 'Console / Game'}
                        </p>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => setFoundRequest(null)}
                        className="flex-1 py-3 bg-white/5 hover:bg-white/10 border border-white/10 text-white font-black rounded-xl text-[10px] uppercase tracking-wider transition-all"
                      >
                        Cancelar
                      </button>
                      <button
                        onClick={handleAuthorizePairing}
                        disabled={isPairingInProgress}
                        className="flex-1 py-3 bg-[#00D1FF] hover:bg-[#00D1FF]/90 text-black font-black rounded-xl text-[10px] uppercase tracking-wider transition-all flex items-center justify-center gap-1"
                      >
                        {isPairingInProgress ? (
                          <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                        ) : 'Confirmar & Ativar'}
                      </button>
                    </div>
                  </div>
                )}

                {pairingMessage && (
                  <div className={`p-4 rounded-2xl text-xs font-semibold leading-relaxed ${
                    pairingSuccess ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/25 animate-bounce' : 'bg-red-500/15 text-red-400 border border-red-500/25'
                  }`}>
                    {pairingSuccess && <CheckCircle2 className="w-4 h-4 inline mr-2 align-text-bottom text-emerald-400" />}
                    {pairingMessage}
                  </div>
                )}
              </div>

              {/* LISTA DE DISPOSITIVOS ATIVOS */}
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-white/5 pb-2">
                  <h5 className="text-[10px] font-black uppercase tracking-widest text-gray-400 flex items-center gap-1.5">
                    <History className="w-3.5 h-3.5 text-gray-500" /> Dispositivos com Acesso Ativo ({activeDevices.length})
                  </h5>
                  <span className="text-[8px] font-black uppercase tracking-widest text-[#00D1FF] bg-[#00D1FF]/5 px-2 py-0.5 rounded border border-[#00D1FF]/10">
                    Sessões Divididas
                  </span>
                </div>

                <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1 scrollbar-thin">
                  {activeDevices.map((device: any) => (
                    <div key={device.id} className="bg-zinc-950/60 hover:bg-zinc-950/90 border border-white/5 p-3 rounded-2xl flex items-center justify-between transition-all gap-3">
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="p-2.5 bg-zinc-900 rounded-xl border border-white/5 shrink-0">
                          {device.type === 'tv' && <Tv className="w-4 h-4 text-gray-400" />}
                          {device.type === 'mobile' && <Smartphone className="w-4 h-4 text-gray-400" />}
                          {device.type === 'desktop' && <Laptop className="w-4 h-4 text-gray-400" />}
                          {device.type === 'console' && <Gamepad2 className="w-4 h-4 text-gray-400" />}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <p className="text-xs font-black text-white uppercase truncate">{device.name}</p>
                            {device.id === 'current-session-id' && (
                              <span className="text-[7px] font-black uppercase bg-emerald-500/10 text-emerald-400 px-1 py-0.2 rounded border border-emerald-500/20">Atual</span>
                            )}
                          </div>
                          <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[8px] text-gray-500 uppercase tracking-wider font-bold mt-0.5">
                            <span className="flex items-center gap-0.5">
                              <Globe className="w-2.5 h-2.5 text-gray-600" /> {device.city || 'Desconhecido'} ({device.ip})
                            </span>
                            <span>•</span>
                            <span>Ativado: {new Date(device.activatedAt).toLocaleDateString('pt-BR')}</span>
                          </div>
                        </div>
                      </div>

                      {device.id !== 'current-session-id' && (
                        <button
                          onClick={() => handleRevokeDevice(device.id, device.name)}
                          className="p-2 text-gray-500 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-all border border-transparent hover:border-red-500/10 cursor-pointer active:scale-90 shrink-0"
                          title="Revogar Acesso"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-zinc-900/20 border border-white/5 p-5 rounded-2xl space-y-3 text-[11px] leading-relaxed text-gray-500 font-medium">
                <p className="font-bold text-white/50 uppercase text-[9px] tracking-widest flex items-center gap-1.5">
                  🛡️ SEGURANÇA E ACORDO DE COMPARTILHAMENTO
                </p>
                <p>
                  Cada dispositivo pareado herda as configurações e acessos do seu plano atual. Você pode revogar o acesso de qualquer dispositivo a qualquer momento nesta tela para desconectá-lo imediatamente.
                </p>
              </div>
            </div>
          )}

          {/* BOTÃO ENCERRAR SESSÃO */}
          <section className="pt-2">
            <button 
              onClick={onLogout} 
              className="w-full py-5 bg-red-950/20 hover:bg-red-950/40 border border-red-500/10 hover:border-red-500/30 text-red-500 font-black text-[10px] uppercase tracking-[0.4em] rounded-full transition-all flex items-center justify-center gap-2 group cursor-pointer active:scale-95"
            >
              <LogOut size={12} className="group-hover:translate-x-1 transition-transform" /> 
              Encerrar Sessão
            </button>
          </section>

        </div>
        
        {/* FOOTER DO MODAL */}
        <div className="p-6 bg-zinc-900/40 border-t border-white/5 flex flex-col items-center gap-2">
          <div className="flex items-center gap-2">
            <div className="w-1.5 h-1.5 bg-[#00D1FF] rounded-full animate-pulse shadow-[0_0_8px_#00D1FF]" />
            <p className="text-[8px] text-gray-500 font-bold uppercase tracking-[0.3em]">
              Sistemas Seguros MONTFLIX PRO • 2026
            </p>
          </div>
        </div>

      </div>
    </div>
  );
};

export default SettingsModal;
