import React, { useState, useEffect, useRef } from 'react';
import { sendVerificationEmail } from '../services/emailService';
import { Security } from '../services/security';
import { Check, Shield, User, CreditCard, Sparkles, AlertCircle, ArrowLeft, Send, CheckCircle2, Copy } from 'lucide-react';

interface PlanSelectionProps {
  onSelectPlan: (plan: 'essencial' | 'padrao' | 'premium', fullName: string, cpf: string) => void;
  userEmail: string;
  onLogout: () => void;
}

const PlanSelection: React.FC<PlanSelectionProps> = ({ onSelectPlan, userEmail, onLogout }) => {
  const [step, setStep] = useState<'plans' | 'form' | 'verification' | 'payment' | 'success'>('plans');
  const [selected, setSelected] = useState<'essencial' | 'padrao' | 'premium'>('premium');
  
  // Dados do Cadastro
  const [fullName, setFullName] = useState('');
  const [cpf, setCpf] = useState('');
  const [email, setEmail] = useState(userEmail);
  const [formError, setFormError] = useState<string | null>(null);

  // Código de Confirmação do Plano
  const [sentCode, setSentCode] = useState('');
  const [userInputCode, setUserInputCode] = useState(['', '', '', '', '', '']);
  const [timer, setTimer] = useState(0);
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationError, setVerificationError] = useState<string | null>(null);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  // Integração Pix
  const [pixData, setPixData] = useState<{ qrcode: string; qrcode_text: string; payment_id: string } | null>(null);
  const [pixLoading, setPixLoading] = useState(false);
  const [pixError, setPixError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [paymentStatusText, setPaymentStatusText] = useState("Aguardando transferência Pix...");

  // Temporizador do Código
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (timer > 0) {
      interval = setInterval(() => {
        setTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [timer]);

  // Polling de Pagamento Pix
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (pixData?.payment_id && step === 'payment') {
      interval = setInterval(async () => {
        try {
          const res = await fetch(`/api/payment/status?id=${pixData.payment_id}`);
          const result = await res.json();

          if (result.status === "COMPLETED" || result.status === "CONCLUÍDA" || result.status === "PAID") {
            setPaymentStatusText("✅ DEPÓSITO PIX CONFIRMADO!");
            clearInterval(interval);
            setTimeout(() => {
              setStep('success');
              setTimeout(() => {
                onSelectPlan(selected, fullName, cpf);
              }, 2500);
            }, 1500);
          }
        } catch (e) {
          console.log("Aguardando confirmação...");
        }
      }, 4000);
    }
    return () => clearInterval(interval);
  }, [pixData, step, selected, fullName, cpf, onSelectPlan]);

  const getPlanDetails = () => {
    switch(selected) {
      case 'essencial': return { name: 'Essencial HD (Com Anúncios)', price: 19.90, desc: 'Qualidade HD • Com anúncios leves' };
      case 'padrao': return { name: 'Padrão Full HD (Sem Anúncios)', price: 39.90, desc: 'Qualidade Full HD • Sem interrupções' };
      case 'premium': 
      default:
        return { name: 'Ultra Premium 4K (Melhor Experiência)', price: 59.90, desc: 'Qualidade Ultra HD 4K + HDR • IPTV Ao Vivo completo • Sem anúncios' };
    }
  };

  const handleCpfChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, '');
    if (val.length > 11) val = val.substring(0, 11);
    
    // Aplicar máscara brasileira de CPF: 000.000.000-00
    if (val.length > 9) {
      val = val.replace(/^(\d{3})(\d{3})(\d{3})(\d{2})$/, '$1.$2.$3-$4');
    } else if (val.length > 6) {
      val = val.replace(/^(\d{3})(\d{3})(\d{0,3})$/, '$1.$2.$3');
    } else if (val.length > 3) {
      val = val.replace(/^(\d{3})(\d{0,3})$/, '$1.$2');
    }
    setCpf(val);
    setFormError(null);
  };

  const handleNextFromPlans = () => {
    setStep('form');
  };

  const generateActivationCode = () => {
    return Math.floor(100000 + Math.random() * 900000).toString();
  };

  // Enviar código de verificação por e-mail para registrar o plano
  const handleSendVerificationCode = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    const cleanCpf = cpf.replace(/\D/g, '');
    if (fullName.trim().length < 5) {
      setFormError("Por favor, insira seu nome completo (mínimo 5 letras).");
      return;
    }
    if (cleanCpf.length !== 11) {
      setFormError("O CPF inserido é inválido. Digite os 11 números corretamente.");
      return;
    }
    if (!email || !email.includes('@')) {
      setFormError("Por favor, insira um e-mail de ativação válido.");
      return;
    }

    setIsVerifying(true);
    const code = generateActivationCode();
    setSentCode(code);

    try {
      const sanitizedEmail = Security.sanitize(email);
      const sent = await sendVerificationEmail(sanitizedEmail, code);
      if (sent) {
        setTimer(60);
        setStep('verification');
        setUserInputCode(['', '', '', '', '', '']);
        setTimeout(() => inputRefs.current[0]?.focus(), 100);
      } else {
        setFormError("Falha ao enviar o e-mail de ativação. Verifique seu e-mail e tente novamente.");
      }
    } catch (e) {
      setFormError("Erro de comunicação ao enviar código de ativação.");
    } finally {
      setIsVerifying(false);
    }
  };

  // Reenviar o código de ativação do plano
  const handleResendActivationCode = async () => {
    if (timer > 0) return;
    setVerificationError(null);
    setIsVerifying(true);
    
    const code = generateActivationCode();
    setSentCode(code);
    
    try {
      const sent = await sendVerificationEmail(Security.sanitize(email), code);
      if (sent) {
        setTimer(60);
        setUserInputCode(['', '', '', '', '', '']);
        inputRefs.current[0]?.focus();
      } else {
        setVerificationError("Falha ao reenviar. Tente em alguns instantes.");
      }
    } catch (e) {
      setVerificationError("Erro de comunicação.");
    } finally {
      setIsVerifying(false);
    }
  };

  const handleCodeInputChange = (index: number, val: string) => {
    if (val.length > 1) val = val.slice(-1);
    if (!/^\d*$/.test(val)) return;

    const newCode = [...userInputCode];
    newCode[index] = val;
    setUserInputCode(newCode);

    if (val !== '' && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleCodeKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && userInputCode[index] === '' && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  // Confirmar código de ativação enviado por e-mail
  const handleVerifyCodeAndAdvance = async () => {
    setVerificationError(null);
    const codeStr = userInputCode.join('');
    if (codeStr.length !== 6) {
      setVerificationError("Por favor, digite o código completo de 6 dígitos.");
      return;
    }

    if (codeStr === sentCode) {
      setIsVerifying(true);
      // Gerar Pix automaticamente para a próxima tela
      await fetchPixDetails();
    } else {
      setVerificationError("Código inválido. Verifique o código em sua caixa de entrada e tente novamente.");
    }
  };

  // Buscar detalhes do PIX gerado via API
  const fetchPixDetails = async () => {
    setPixLoading(true);
    setPixError(null);
    const planInfo = getPlanDetails();

    try {
      const response = await fetch('/api/payment/pix', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          amount: planInfo.price, 
          planName: planInfo.name,
          userEmail: Security.sanitize(email)
        })
      });
      
      const data = await response.json();
      if (data.success && (data.qrcode_text || data.qrcode)) {
        setPixData({
          qrcode: data.qrcode,
          qrcode_text: data.qrcode_text,
          payment_id: data.payment_id
        });
        setStep('payment');
      } else {
        setPixError(data.error || "Ambiente bancário indisponível momentaneamente. Tente novamente.");
        setStep('verification'); // Volta para que possa tentar gerar de novo
      }
    } catch (err) {
      setPixError("Sem conexão com o servidor de pagamentos.");
      setStep('verification');
    } finally {
      setPixLoading(false);
      setIsVerifying(false);
    }
  };

  const handleCopyPixCode = () => {
    if (pixData?.qrcode_text) {
      navigator.clipboard.writeText(pixData.qrcode_text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="min-h-screen bg-[#060608] text-white font-sans flex flex-col justify-between selection:bg-[#00D1FF] selection:text-black">
      
      {/* HEADER PREMIUM */}
      <nav className="px-6 md:px-16 py-6 flex justify-between items-center border-b border-white/5 bg-zinc-950/60 backdrop-blur-2xl sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <span className="text-3xl font-black italic tracking-tighter text-white">
            MONT<span className="text-[#00D1FF] drop-shadow-[0_0_15px_#00D1FF]">FLIX</span>
          </span>
          <span className="text-[8px] bg-white/10 px-2 py-0.5 rounded-full uppercase tracking-widest text-white/50 border border-white/5">PRO</span>
        </div>
        <button 
          onClick={onLogout} 
          className="px-4 py-2 border border-white/10 hover:border-red-500/50 hover:text-red-500 rounded-full text-xs font-black uppercase tracking-widest transition-all active:scale-95 bg-white/5"
        >
          Desconectar
        </button>
      </nav>

      {/* ÁREA CENTRAL DO WIZARD */}
      <div className="max-w-4xl w-full mx-auto px-6 py-12 md:py-16 flex-1 flex flex-col justify-center">
        
        {/* INDICADOR DE PASSO EXPLICATIVO */}
        <div className="flex items-center justify-center gap-4 mb-10 max-w-md mx-auto">
          <div className="flex flex-col items-center gap-1.5 flex-1">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black border transition-all ${
              step === 'plans' ? 'bg-[#00D1FF] border-[#00D1FF] text-black shadow-[0_0_15px_rgba(0,209,255,0.4)]' : 'bg-zinc-900 border-white/10 text-white/40'
            }`}>1</div>
            <span className="text-[8px] font-black uppercase tracking-wider text-gray-500">Planos</span>
          </div>
          <div className="h-[2px] bg-white/5 w-10 mb-3" />
          <div className="flex flex-col items-center gap-1.5 flex-1">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black border transition-all ${
              step === 'form' ? 'bg-[#00D1FF] border-[#00D1FF] text-black shadow-[0_0_15px_rgba(0,209,255,0.4)]' : 'bg-zinc-900 border-white/10 text-white/40'
            }`}>2</div>
            <span className="text-[8px] font-black uppercase tracking-wider text-gray-500">Cadastro</span>
          </div>
          <div className="h-[2px] bg-white/5 w-10 mb-3" />
          <div className="flex flex-col items-center gap-1.5 flex-1">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black border transition-all ${
              step === 'verification' ? 'bg-[#00D1FF] border-[#00D1FF] text-black shadow-[0_0_15px_rgba(0,209,255,0.4)]' : 'bg-zinc-900 border-white/10 text-white/40'
            }`}>3</div>
            <span className="text-[8px] font-black uppercase tracking-wider text-gray-500">Ativação</span>
          </div>
          <div className="h-[2px] bg-white/5 w-10 mb-3" />
          <div className="flex flex-col items-center gap-1.5 flex-1">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black border transition-all ${
              step === 'payment' ? 'bg-[#00D1FF] border-[#00D1FF] text-black shadow-[0_0_15px_rgba(0,209,255,0.4)]' : 'bg-zinc-900 border-white/10 text-white/40'
            }`}>4</div>
            <span className="text-[8px] font-black uppercase tracking-wider text-gray-500">Acesso</span>
          </div>
        </div>

        {/* STEP 1: COMPARADOR DE PLANOS */}
        {step === 'plans' && (
          <div className="space-y-10 animate-in fade-in slide-in-from-bottom-5 duration-500">
            <div className="text-center max-w-2xl mx-auto space-y-4">
              <span className="px-4 py-1.5 bg-[#00D1FF]/10 border border-[#00D1FF]/20 text-[#00D1FF] font-black uppercase text-[10px] tracking-widest rounded-full">
                Sinal Instantâneo HD & 4K Ultra HD
              </span>
              <h1 className="text-3xl md:text-5xl font-black italic tracking-tighter uppercase leading-tight">
                Escolha o plano que combina com seu cinema particular
              </h1>
              <p className="text-gray-400 text-sm md:text-base">
                Acesse o catálogo completo do TMDB, canais ao vivo IPTV premium e transmissões esportivas sem limites.
              </p>
            </div>

            {/* SELEÇÃO DO PLANO GRID */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
              
              {/* ESSENCIAL */}
              <div 
                onClick={() => setSelected('essencial')}
                className={`cursor-pointer relative p-8 rounded-3xl border transition-all duration-300 flex flex-col justify-between ${
                  selected === 'essencial' 
                    ? 'border-[#00D1FF] bg-white/[0.03] shadow-[0_0_30px_rgba(0,209,255,0.15)] ring-2 ring-[#00D1FF]/30 scale-[1.02]' 
                    : 'border-white/5 bg-zinc-900/20 hover:border-white/10 hover:bg-zinc-900/30'
                }`}
              >
                <div className="space-y-4">
                  <div className="flex justify-between items-start">
                    <span className="px-2.5 py-1 bg-white/5 border border-white/10 text-gray-400 font-black rounded text-[8px] uppercase tracking-wider">HD COM ADS</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-black italic text-white uppercase tracking-tight">Essencial</h3>
                    <p className="text-xs text-gray-400 mt-1">Ótimo custo benefício</p>
                  </div>
                  <div className="h-px bg-white/5 w-full" />
                  <ul className="space-y-3.5 text-xs text-gray-300">
                    <li className="flex items-center gap-2"><Check size={12} className="text-[#00D1FF]" /> Qualidade HD (720p)</li>
                    <li className="flex items-center gap-2"><Check size={12} className="text-[#00D1FF]" /> Filmes & Séries Ilimitados</li>
                    <li className="flex items-center gap-2"><Check size={12} className="text-[#00D1FF]" /> Canais de TV inclusos</li>
                    <li className="flex items-center gap-2 text-white/30"><span className="text-red-500/40">✕</span> Anúncios pontuais</li>
                  </ul>
                </div>
                <div className="pt-8">
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-black">R$ 19,90</span>
                    <span className="text-gray-500 font-bold text-sm">/mês</span>
                  </div>
                </div>
              </div>

              {/* PADRÃO */}
              <div 
                onClick={() => setSelected('padrao')}
                className={`cursor-pointer relative p-8 rounded-3xl border transition-all duration-300 flex flex-col justify-between ${
                  selected === 'padrao' 
                    ? 'border-[#00D1FF] bg-white/[0.03] shadow-[0_0_30px_rgba(0,209,255,0.15)] ring-2 ring-[#00D1FF]/30 scale-[1.02]' 
                    : 'border-white/5 bg-zinc-900/20 hover:border-white/10 hover:bg-zinc-900/30'
                }`}
              >
                <div className="space-y-4">
                  <div className="flex justify-between items-start">
                    <span className="px-2.5 py-1 bg-white/5 border border-white/10 text-cyan-400 font-black rounded text-[8px] uppercase tracking-wider">FULL HD</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-black italic text-white uppercase tracking-tight">Padrão</h3>
                    <p className="text-xs text-gray-400 mt-1">Transmissão limpa sem anúncios</p>
                  </div>
                  <div className="h-px bg-white/5 w-full" />
                  <ul className="space-y-3.5 text-xs text-gray-300">
                    <li className="flex items-center gap-2"><Check size={12} className="text-[#00D1FF]" /> Qualidade Full HD (1080p)</li>
                    <li className="flex items-center gap-2"><Check size={12} className="text-[#00D1FF]" /> 100% Livre de anúncios</li>
                    <li className="flex items-center gap-2"><Check size={12} className="text-[#00D1FF]" /> Canais de TV HD premium</li>
                    <li className="flex items-center gap-2"><Check size={12} className="text-[#00D1FF]" /> 2 telas simultâneas</li>
                  </ul>
                </div>
                <div className="pt-8">
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-black">R$ 39,90</span>
                    <span className="text-gray-500 font-bold text-sm">/mês</span>
                  </div>
                </div>
              </div>

              {/* PREMIUM 4K */}
              <div 
                onClick={() => setSelected('premium')}
                className={`cursor-pointer relative p-8 rounded-3xl border transition-all duration-300 flex flex-col justify-between ${
                  selected === 'premium' 
                    ? 'border-[#00D1FF] bg-[#00D1FF]/5 shadow-[0_0_40px_rgba(0,209,255,0.25)] ring-2 ring-[#00D1FF] scale-[1.04]' 
                    : 'border-white/5 bg-zinc-900/20 hover:border-white/10 hover:bg-zinc-900/30'
                }`}
              >
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-[#00D1FF] text-black text-[8px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest shadow-lg flex items-center gap-1">
                  <Sparkles size={8} /> Melhor Experiência
                </div>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-start">
                    <span className="px-2.5 py-1 bg-[#00D1FF]/20 border border-[#00D1FF]/40 text-[#00D1FF] font-black rounded text-[8px] uppercase tracking-wider">ULTRA HD 4K</span>
                  </div>
                  <div>
                    <h3 className="text-xl font-black italic text-white uppercase tracking-tight">Ultra Premium 4K</h3>
                    <p className="text-xs text-gray-400 mt-1">Qualidade máxima de som e imagem</p>
                  </div>
                  <div className="h-px bg-white/5 w-full" />
                  <ul className="space-y-3.5 text-xs text-gray-300">
                    <li className="flex items-center gap-2"><Check size={12} className="text-[#00D1FF]" /> UHD 4K & HDR ativado</li>
                    <li className="flex items-center gap-2"><Check size={12} className="text-[#00D1FF]" /> Livre de anúncios</li>
                    <li className="flex items-center gap-2"><Check size={12} className="text-[#00D1FF]" /> Canais IPTV Premium 4K/60fps</li>
                    <li className="flex items-center gap-2"><Check size={12} className="text-[#00D1FF]" /> 4 telas simultâneas + Dolby Atmos</li>
                  </ul>
                </div>
                <div className="pt-8">
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-black">R$ 59,90</span>
                    <span className="text-gray-500 font-bold text-sm">/mês</span>
                  </div>
                </div>
              </div>

            </div>

            {/* BOTÃO PRÓXIMO */}
            <div className="flex flex-col items-center gap-4 pt-4">
              <button 
                onClick={handleNextFromPlans}
                className="w-full sm:w-auto sm:px-24 bg-[#00D1FF] hover:bg-white text-black font-black py-5 rounded-full text-xs uppercase tracking-[0.3em] transition-all transform hover:scale-[1.03] active:scale-95 shadow-[0_0_35px_rgba(0,209,255,0.4)] cursor-pointer"
              >
                Avançar para Cadastro
              </button>
              <div className="flex items-center gap-1 text-[10px] text-gray-500 uppercase tracking-widest font-bold">
                <Shield size={10} className="text-[#00D1FF]" /> Ambiente Segurado & Criptografado
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: FORMULÁRIO DE CADASTRO COM CPF E NOME */}
        {step === 'form' && (
          <div className="max-w-md w-full mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-5 duration-500">
            <div className="text-center space-y-3">
              <button 
                onClick={() => setStep('plans')}
                className="inline-flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-gray-500 hover:text-white mb-2"
              >
                <ArrowLeft size={10} /> Voltar para Planos
              </button>
              <h2 className="text-3xl font-black uppercase tracking-tighter italic">Detalhes de Ativação do Plano</h2>
              <p className="text-xs text-gray-400">
                Preencha as informações para registrar o plano <span className="text-[#00D1FF] font-black">{getPlanDetails().name}</span> em seu CPF de forma oficial.
              </p>
            </div>

            <form onSubmit={handleSendVerificationCode} className="space-y-6 bg-zinc-950/60 p-8 rounded-3xl border border-white/5 shadow-2xl">
              
              {/* Nome Completo */}
              <div className="space-y-2">
                <label className="text-[9px] font-black uppercase tracking-widest text-gray-500 flex items-center gap-1.5">
                  <User size={10} className="text-[#00D1FF]" /> Nome Completo
                </label>
                <input 
                  type="text" 
                  required 
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Nome e Sobrenome"
                  className="w-full px-5 py-4 bg-white/5 border border-white/10 rounded-2xl text-white text-sm focus:outline-none focus:border-[#00D1FF] transition-all placeholder-white/20"
                />
              </div>

              {/* CPF */}
              <div className="space-y-2">
                <label className="text-[9px] font-black uppercase tracking-widest text-gray-500 flex items-center gap-1.5">
                  <CreditCard size={10} className="text-[#00D1FF]" /> CPF para Registro
                </label>
                <input 
                  type="text" 
                  required 
                  value={cpf}
                  onChange={handleCpfChange}
                  placeholder="000.000.000-00"
                  className="w-full px-5 py-4 bg-white/5 border border-white/10 rounded-2xl text-white text-sm font-mono focus:outline-none focus:border-[#00D1FF] transition-all placeholder-white/20"
                />
              </div>

              {/* Email (Confirmar) */}
              <div className="space-y-2">
                <label className="text-[9px] font-black uppercase tracking-widest text-gray-500 flex items-center gap-1.5">
                  <CheckCircle2 size={10} className="text-[#00D1FF]" /> E-mail de Ativação
                </label>
                <input 
                  type="email" 
                  required 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="seuemail@exemplo.com"
                  className="w-full px-5 py-4 bg-white/5 border border-white/10 rounded-2xl text-white text-sm focus:outline-none focus:border-[#00D1FF] transition-all placeholder-white/20"
                />
              </div>

              {formError && (
                <div className="p-4 bg-red-950/20 border border-red-500/20 text-red-500 rounded-2xl text-xs flex items-start gap-2">
                  <AlertCircle size={14} className="shrink-0 mt-0.5" />
                  <span>{formError}</span>
                </div>
              )}

              <button 
                type="submit" 
                disabled={isVerifying}
                className="w-full bg-[#00D1FF] hover:bg-white text-black font-black py-5 rounded-2xl text-xs uppercase tracking-[0.3em] transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {isVerifying ? (
                  <>
                    <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                    Enviando código...
                  </>
                ) : (
                  <>
                    <Send size={12} />
                    Avançar para Ativação
                  </>
                )}
              </button>
            </form>

            <p className="text-center text-gray-500 text-[10px] leading-relaxed uppercase tracking-wider font-bold">
              🔒 Seus dados cadastrais estão 100% seguros sob criptografia de ponta a ponta e em conformidade com as diretrizes de segurança da rede.
            </p>
          </div>
        )}

        {/* STEP 3: TELA DE CONFIRMAÇÃO DO CÓDIGO DO PLANO (ENVIADO POR E-MAIL) */}
        {step === 'verification' && (
          <div className="max-w-md w-full mx-auto space-y-8 animate-in fade-in zoom-in-95 duration-500 text-center">
            <div className="space-y-3">
              <button 
                onClick={() => setStep('form')}
                className="inline-flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-gray-500 hover:text-white mb-2"
              >
                <ArrowLeft size={10} /> Voltar para Cadastro
              </button>
              <h2 className="text-3xl font-black uppercase tracking-tighter italic">Confirmar Código de Ativação</h2>
              <p className="text-xs text-gray-400">
                Enviamos um código exclusivo de segurança para o e-mail: <span className="text-[#00D1FF] font-black font-mono">{email}</span>. Digite-o para ativar seu CPF e liberar o Pix.
              </p>
            </div>

            <div className="bg-zinc-950/60 p-8 rounded-3xl border border-white/5 shadow-2xl space-y-8">
              
              {/* Inputs de Código Separados */}
              <div className="flex justify-between gap-2 max-w-xs mx-auto">
                {userInputCode.map((digit, idx) => (
                  <input
                    key={idx}
                    ref={(el) => { inputRefs.current[idx] = el; }}
                    type="text"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleCodeInputChange(idx, e.target.value)}
                    onKeyDown={(e) => handleCodeKeyDown(idx, e)}
                    className="w-12 h-16 bg-white/5 border border-white/10 rounded-2xl text-center text-2xl font-black text-[#00D1FF] focus:outline-none focus:border-[#00D1FF] shadow-inner font-mono"
                  />
                ))}
              </div>

              {verificationError && (
                <div className="p-4 bg-red-950/20 border border-red-500/20 text-red-500 rounded-2xl text-xs flex items-center justify-center gap-2">
                  <AlertCircle size={14} className="shrink-0" />
                  <span>{verificationError}</span>
                </div>
              )}

              {/* Botão Avançar */}
              <button
                onClick={handleVerifyCodeAndAdvance}
                disabled={isVerifying}
                className="w-full bg-white hover:bg-[#00D1FF] text-black font-black py-5 rounded-2xl text-xs uppercase tracking-[0.4em] transition-all flex items-center justify-center gap-2"
              >
                {isVerifying ? (
                  <>
                    <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                    Autenticando...
                  </>
                ) : (
                  "Verificar e Liberar Sinal"
                )}
              </button>

              {/* Reenviar */}
              <div className="pt-2">
                <button
                  onClick={handleResendActivationCode}
                  disabled={timer > 0 || isVerifying}
                  className="text-[10px] font-black uppercase tracking-widest text-gray-500 hover:text-white transition-colors disabled:opacity-40"
                >
                  {timer > 0 ? `Reenviar código em ${timer}s` : 'Não recebeu? Reenviar código'}
                </button>
              </div>

            </div>
          </div>
        )}

        {/* STEP 4: TELA DO PAGAMENTO PIX */}
        {step === 'payment' && (
          <div className="max-w-md w-full mx-auto space-y-8 animate-in fade-in zoom-in-95 duration-500 text-center">
            <div className="space-y-3">
              <h2 className="text-3xl font-black uppercase tracking-tighter italic">Pagamento do Sinal</h2>
              <p className="text-xs text-gray-400">
                Ative seu plano <span className="text-[#00D1FF] font-black">{getPlanDetails().name}</span> via Pix Copia e Cola ou QR Code.
              </p>
            </div>

            <div className="bg-zinc-950 p-8 rounded-3xl border border-white/5 shadow-2xl space-y-6">
              
              <div className="flex justify-center">
                {pixLoading ? (
                  <div className="w-[200px] h-[200px] flex items-center justify-center bg-white/5 border border-white/10 rounded-2xl">
                    <div className="w-8 h-8 border-2 border-[#00D1FF] border-t-transparent rounded-full animate-spin" />
                  </div>
                ) : pixError ? (
                  <div className="w-[200px] h-[200px] flex flex-col items-center justify-center bg-red-950/20 border border-red-500/20 rounded-2xl p-4">
                    <p className="text-xs text-red-500 font-bold leading-tight mb-2">{pixError}</p>
                    <button onClick={fetchPixDetails} className="text-xs text-[#00D1FF] underline font-black">Tentar Novamente</button>
                  </div>
                ) : (
                  <div className="p-3 bg-white rounded-2xl shadow-xl border border-white/10 shrink-0">
                    <img 
                      src={pixData?.qrcode} 
                      alt="QR Code Pix"
                      className="w-[180px] h-[180px] block"
                    />
                  </div>
                )}
              </div>

              {/* Informações de Preço */}
              <div className="p-4 bg-white/[0.02] border border-white/5 rounded-2xl text-left space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400 font-bold uppercase tracking-wider">Beneficiário</span>
                  <span className="text-white font-black">MONTFLIX SEGURADORA</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400 font-bold uppercase tracking-wider">CPF Registrado</span>
                  <span className="text-white font-black font-mono">{cpf}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-gray-400 font-bold uppercase tracking-wider">Valor do Plano</span>
                  <span className="text-[#00D1FF] font-black">R$ {getPlanDetails().price.toFixed(2)}</span>
                </div>
              </div>

              <div className="space-y-3">
                <input 
                  type="text" 
                  readOnly 
                  value={pixData?.qrcode_text || ""} 
                  placeholder={pixLoading ? "Gerando código do Pix..." : "Código Copia e Cola"}
                  onClick={handleCopyPixCode}
                  className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-[10px] font-mono text-center text-white focus:outline-none cursor-pointer"
                />
                
                <button 
                  onClick={handleCopyPixCode}
                  className={`w-full py-4 rounded-xl font-black text-xs uppercase tracking-widest transition-all flex items-center justify-center gap-2 ${
                    copied 
                      ? 'bg-green-500 text-white shadow-[0_0_20px_rgba(34,197,94,0.3)]' 
                      : 'bg-[#00D1FF] hover:bg-white text-black shadow-[0_0_20px_rgba(0,209,255,0.2)]'
                  }`}
                >
                  <Copy size={12} />
                  {copied ? 'CÓDIGO COPIADO!' : 'COPIAR CÓDIGO PIX'}
                </button>
              </div>

              {/* Status de Confirmação em Tempo Real */}
              <div className="flex items-center justify-center gap-2.5 pt-3 text-xs font-black uppercase tracking-wider">
                <div className="w-2 h-2 bg-yellow-500 rounded-full animate-ping" />
                <span className="text-yellow-500">{paymentStatusText}</span>
              </div>

            </div>
          </div>
        )}

        {/* STEP 5: ATIVAÇÃO SUCESSO */}
        {step === 'success' && (
          <div className="max-w-md w-full mx-auto space-y-6 text-center animate-in zoom-in-95 duration-500 py-12">
            <div className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center mx-auto shadow-[0_0_50px_rgba(34,197,94,0.5)]">
              <Check size={48} className="text-white stroke-[4px]" />
            </div>
            
            <div className="space-y-3">
              <h2 className="text-4xl font-black uppercase tracking-tighter italic">CPF Ativado com Sucesso!</h2>
              <p className="text-green-400 text-xs font-black uppercase tracking-[0.2em]">
                O sinal foi liberado instantaneamente!
              </p>
              <p className="text-gray-400 text-sm max-w-sm mx-auto pt-2">
                Seja muito bem-vindo ao futuro do streaming. Direcionando você para a sala de cinema...
              </p>
            </div>
          </div>
        )}

      </div>

      {/* FOOTER */}
      <footer className="text-center py-6 text-[10px] text-gray-600 font-bold uppercase tracking-widest border-t border-white/5">
        Montflix © 2026 • Todos os Direitos Reservados
      </footer>

    </div>
  );
};

export default PlanSelection;
