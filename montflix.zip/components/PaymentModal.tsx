
import React, { useState, useEffect, useCallback } from 'react';

interface PaymentModalProps {
  planName: string;
  price: number;
  onSuccess: () => void;
  onClose: () => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({ planName, price, onSuccess, onClose }) => {
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);
  const [step, setStep] = useState<'payment' | 'success'>('payment');
  const [pixData, setPixData] = useState<{ qrcode: string; qrcode_text: string; payment_id: string } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [statusText, setStatusText] = useState("Aguardando depósito...");

  const generatePix = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/payment/pix', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          amount: price, 
          planName,
          userEmail: localStorage.getItem('montflix_user_email') || 'usuario@montflix.com'
        })
      });
      
      const data = await response.json();
      if (data.success && (data.qrcode_text || data.qrcode)) {
        setPixData({
          qrcode: data.qrcode,
          qrcode_text: data.qrcode_text,
          payment_id: data.payment_id
        });
      } else {
        setError(data.error || "A API não retornou os dados do PIX. Verifique sua chave.");
      }
    } catch (err) {
      setError("Erro de conexão com o servidor");
    } finally {
      setLoading(false);
    }
  }, [price, planName]);

  useEffect(() => {
    generatePix();
  }, [generatePix]);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (pixData?.payment_id && step === 'payment') {
      interval = setInterval(async () => {
        try {
          const res = await fetch(`/api/payment/status?id=${pixData.payment_id}`);
          const result = await res.json();

          if (result.status === "COMPLETED" || result.status === "CONCLUÍDA" || result.status === "PAID") {
            setStatusText("✅ DEPÓSITO RECEBIDO!");
            clearInterval(interval);
            setTimeout(() => {
              setStep('success');
              setTimeout(() => onSuccess(), 2000);
            }, 1500);
          }
        } catch (e) {
          console.log("Aguardando confirmação...");
        }
      }, 5000);
    }
    return () => clearInterval(interval);
  }, [pixData, step, onSuccess]);

  const handleCopyPix = () => {
    if (pixData?.qrcode_text) {
      navigator.clipboard.writeText(pixData.qrcode_text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  if (step === 'success') {
    return (
      <div className="fixed inset-0 z-[700] flex items-center justify-center bg-black/95 backdrop-blur-xl">
        <div className="text-center space-y-6 animate-in zoom-in-95 duration-500">
          <div className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center mx-auto shadow-[0_0_50px_rgba(34,197,94,0.4)]">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <div className="space-y-2">
            <h2 className="text-white font-black text-3xl uppercase tracking-tighter">Ativado!</h2>
            <p className="text-green-500 text-xs font-black uppercase tracking-[0.3em]">Sinal liberado! Bem-vindo à Montflix.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-[600] flex items-center justify-center bg-black/80 backdrop-blur-sm">
      <div id="overlay" className="absolute inset-0" onClick={onClose}></div>
      
      <div id="modalPix" className="relative w-[320px] bg-white rounded-[15px] p-5 text-center text-[#333] shadow-[0_10px_25px_rgba(0,0,0,0.5)] animate-in zoom-in-95 duration-300">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">✕</button>
        
        <h3 className="m-0 text-xl font-bold">Pagamento via Pix</h3>
        <p className="text-[12px] text-[#666] mt-1">Aponte a câmera ou copie o código</p>
        
        <div className="my-4 flex justify-center">
          {loading ? (
            <div className="w-[180px] h-[180px] flex items-center justify-center bg-gray-50 border border-gray-100 rounded-xl">
              <div className="w-8 h-8 border-2 border-[#00D1FF] border-t-transparent rounded-full animate-spin"></div>
            </div>
          ) : error ? (
            <div className="w-[180px] h-[180px] flex flex-col items-center justify-center bg-red-50 border border-red-100 rounded-xl p-4">
              <p className="text-[10px] text-red-600 font-bold leading-tight">{error}</p>
              <button onClick={generatePix} className="mt-2 text-[10px] text-red-600 underline">Tentar novamente</button>
            </div>
          ) : (
            <img 
              id="qrImage" 
              className="w-[180px] h-[180px] border border-[#eee] block mx-auto" 
              src={pixData?.qrcode} 
              alt="QR Code" 
            />
          )}
        </div>
        
        <input 
          type="text" 
          id="pixCode" 
          className="w-[90%] p-2.5 mt-2 border border-[#ddd] rounded-lg text-[11px] text-center bg-[#f9f9f9] cursor-pointer focus:outline-none" 
          readOnly 
          value={pixData?.qrcode_text || ""} 
          placeholder={loading ? "Gerando código..." : "Código Pix"}
          onClick={handleCopyPix}
        />
        
        <button 
          className={`w-full text-white border-none p-3 rounded-lg font-bold cursor-pointer mt-3 text-sm transition-all ${copied ? 'bg-green-600' : 'bg-[#00D1FF] hover:bg-[#00B8E6] text-black'}`}
          onClick={handleCopyPix}
        >
          {copied ? 'CÓDIGO COPIADO!' : 'COPIAR CÓDIGO PIX'}
        </button>
        
        <div id="statusPagamento" className={`mt-4 text-[13px] font-bold ${statusText.includes('✅') ? 'text-green-600' : 'text-[#e67e22]'}`}>
          {statusText}
        </div>
      </div>
    </div>
  );
};

export default PaymentModal;
