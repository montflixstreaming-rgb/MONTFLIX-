import React from 'react';
import { Home, Tv, Star, User } from 'lucide-react';

interface BottomNavProps {
  currentView: string;
  onViewChange: (view: string) => void;
  onOpenSettings: () => void;
  userAvatar: string | null;
}

const BottomNav: React.FC<BottomNavProps> = ({
  currentView,
  onViewChange,
  onOpenSettings,
  userAvatar
}) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 z-[200] pb-safe-bottom">
      {/* Sombra de desbotamento no fundo */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black via-black/80 to-transparent pointer-events-none" />

      {/* Container Flutuante da Barra de Navegação */}
      <div className="relative max-w-md mx-auto px-6 pb-6 pt-2">
        <div className="bg-zinc-950/80 backdrop-blur-3xl border border-white/10 rounded-full px-4 py-3 flex items-center justify-around shadow-[0_-10px_35px_rgba(0,0,0,0.8),0_0_25px_rgba(0,209,255,0.08)]">
          
          {/* INÍCIO (HOME) */}
          <button
            onClick={() => onViewChange('home')}
            className="flex flex-col items-center justify-center gap-1 flex-1 py-1 group outline-none relative"
          >
            <div className={`p-1.5 rounded-full transition-all duration-300 ${
              currentView === 'home' 
                ? 'text-[#00D1FF] scale-110 drop-shadow-[0_0_8px_rgba(0,209,255,0.5)]' 
                : 'text-white/40 hover:text-white/80'
            }`}>
              <Home size={20} strokeWidth={currentView === 'home' ? 2.5 : 2} />
            </div>
            <span className={`text-[9px] font-black tracking-widest uppercase transition-all duration-300 ${
              currentView === 'home' ? 'text-[#00D1FF]' : 'text-white/30 group-hover:text-white/60'
            }`}>
              Início
            </span>
            {currentView === 'home' && (
              <div className="absolute -bottom-1.5 w-4 h-[3px] bg-[#00D1FF] rounded-full shadow-[0_0_10px_#00D1FF]" />
            )}
          </button>

          {/* AO VIVO (TV/IPTV) */}
          <button
            onClick={() => onViewChange('iptv')}
            className="flex flex-col items-center justify-center gap-1 flex-1 py-1 group outline-none relative"
          >
            <div className={`p-1.5 rounded-full transition-all duration-300 ${
              currentView === 'iptv' 
                ? 'text-[#00D1FF] scale-110 drop-shadow-[0_0_8px_rgba(0,209,255,0.5)]' 
                : 'text-white/40 hover:text-white/80'
            }`}>
              <Tv size={20} strokeWidth={currentView === 'iptv' ? 2.5 : 2} />
            </div>
            <span className={`text-[9px] font-black tracking-widest uppercase transition-all duration-300 ${
              currentView === 'iptv' ? 'text-[#00D1FF]' : 'text-white/30 group-hover:text-white/60'
            }`}>
              Ao Vivo
            </span>
            {currentView === 'iptv' && (
              <div className="absolute -bottom-1.5 w-4 h-[3px] bg-[#00D1FF] rounded-full shadow-[0_0_10px_#00D1FF]" />
            )}
          </button>

          {/* FAVORITOS (MINHA LISTA) */}
          <button
            onClick={() => onViewChange('favorites')}
            className="flex flex-col items-center justify-center gap-1 flex-1 py-1 group outline-none relative"
          >
            <div className={`p-1.5 rounded-full transition-all duration-300 ${
              currentView === 'favorites' 
                ? 'text-[#00D1FF] scale-110 drop-shadow-[0_0_8px_rgba(0,209,255,0.5)]' 
                : 'text-white/40 hover:text-white/80'
            }`}>
              <Star size={20} strokeWidth={currentView === 'favorites' ? 2.5 : 2} fill={currentView === 'favorites' ? 'currentColor' : 'none'} />
            </div>
            <span className={`text-[9px] font-black tracking-widest uppercase transition-all duration-300 ${
              currentView === 'favorites' ? 'text-[#00D1FF]' : 'text-white/30 group-hover:text-white/60'
            }`}>
              Favoritos
            </span>
            {currentView === 'favorites' && (
              <div className="absolute -bottom-1.5 w-4 h-[3px] bg-[#00D1FF] rounded-full shadow-[0_0_10px_#00D1FF]" />
            )}
          </button>

          {/* MEU PERFIL (AÇÃO SETTINGS) */}
          <button
            onClick={onOpenSettings}
            className="flex flex-col items-center justify-center gap-1 flex-1 py-1 group outline-none relative"
          >
            <div className="relative p-1 transition-all duration-300 group-hover:scale-105 active:scale-95">
              {userAvatar ? (
                <div className="w-6 h-6 rounded-full overflow-hidden border border-white/20 group-hover:border-[#00D1FF]/80 transition-all shadow-md">
                  <img src={userAvatar} className="w-full h-full object-cover" alt="Perfil" />
                </div>
              ) : (
                <div className="text-white/40 group-hover:text-white/80">
                  <User size={20} />
                </div>
              )}
            </div>
            <span className="text-[9px] font-black tracking-widest uppercase text-white/30 group-hover:text-white/60">
              Perfil
            </span>
          </button>

        </div>
      </div>
    </div>
  );
};

export default BottomNav;
