import React, { useEffect, useState } from 'react';
import { Movie } from '../services/types';
import { tmdbService } from '../services/tmdbService';

interface MovieDetailModalProps {
  movie: Movie;
  onClose: () => void;
  onWatchFullMovie: (movie: Movie) => void;
  userPlan?: 'essencial' | 'padrao' | 'premium';
  myList: Movie[];
  onToggleFavorite: (movie: Movie) => void;
}

const MovieDetailModal: React.FC<MovieDetailModalProps> = ({
  movie,
  onClose,
  onWatchFullMovie,
  userPlan,
  myList,
  onToggleFavorite
}) => {
  const [trailerUrl, setTrailerUrl] = useState<string | null>(null);
  const [loadingTrailer, setLoadingTrailer] = useState(true);
  const isFavorite = !!myList.find((m) => m.id === movie.id);

  useEffect(() => {
    // Impedir scroll na página por baixo do modal
    document.body.style.overflow = 'hidden';

    // Buscar o trailer do TMDB
    let active = true;
    const fetchTrailer = async () => {
      try {
        const url = await tmdbService.getMovieTrailer(movie.id);
        if (active) {
          setTrailerUrl(url);
          setLoadingTrailer(false);
        }
      } catch (e) {
        console.error("Error loading movie trailer:", e);
        if (active) {
          setLoadingTrailer(false);
        }
      }
    };

    fetchTrailer();

    return () => {
      active = false;
      document.body.style.overflow = 'unset';
    };
  }, [movie.id]);

  return (
    <div className="fixed inset-0 z-[500] bg-black/90 backdrop-blur-2xl flex items-center justify-center p-4 md:p-6 lg:p-12 overflow-y-auto animate-in fade-in duration-300">
      
      {/* Container Principal */}
      <div className="relative max-w-5xl w-full bg-zinc-950 border border-white/10 rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(0,209,255,0.15)] flex flex-col md:my-8">
        
        {/* BOTÃO FECHAR FLUTUANTE ULTRA MODERN */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-[550] w-10 h-10 md:w-12 md:h-12 flex items-center justify-center rounded-full bg-black/60 hover:bg-[#00D1FF] text-white hover:text-black border border-white/10 hover:border-[#00D1FF] transition-all active:scale-95 duration-300 group cursor-pointer"
          title="Fechar Detalhes"
        >
          <span className="text-lg md:text-xl font-light group-hover:scale-110 transition-transform">✕</span>
        </button>

        {/* ÁREA SUPERIOR: TRAILER COM SOM / BACKDROP HERO */}
        <div className="relative w-full aspect-video bg-black overflow-hidden border-b border-white/5">
          {loadingTrailer ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-zinc-900/60 z-20">
              <div className="w-12 h-12 border-4 border-[#00D1FF] border-t-transparent rounded-full animate-spin shadow-[0_0_15px_#00D1FF]" />
              <p className="text-white/40 text-xs font-black uppercase tracking-widest animate-pulse">
                Carregando Trailer com som premium...
              </p>
            </div>
          ) : null}

          {/* Se achou o trailer, carrega o iframe do YouTube */}
          {!loadingTrailer && trailerUrl ? (
            <iframe
              src={trailerUrl}
              className="w-full h-full border-0 absolute inset-0 z-10"
              allow="autoplay; encrypted-media; picture-in-picture"
              allowFullScreen
              title={`Trailer de ${movie.title}`}
            />
          ) : (
            // Se não encontrou o trailer, mostra o backdrop lindo como fallback com um aviso visual elegante
            <div className="absolute inset-0 w-full h-full z-10">
              <img
                src={movie.backdropUrl || movie.posterUrl}
                className="w-full h-full object-cover opacity-60"
                alt={movie.title}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 md:bottom-10 md:left-10 md:right-10 flex flex-col gap-2 z-20">
                <span className="px-3 py-1 bg-white/10 border border-white/20 rounded-full text-[10px] font-bold uppercase tracking-wider text-white w-max">
                  Trailer Indisponível
                </span>
                <p className="text-white/60 text-xs md:text-sm">
                  Não localizamos o vídeo do trailer deste filme nos servidores oficiais, mas você pode assisti-lo completo agora mesmo!
                </p>
              </div>
            </div>
          )}

          {/* Sombra escura de gradiente para misturar o trailer com a seção de informações */}
          <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-zinc-950 to-transparent pointer-events-none z-30" />
        </div>

        {/* ÁREA INFERIOR: INFORMAÇÕES DO FILME & BOTÕES DE AÇÃO */}
        <div className="p-6 md:p-10 lg:p-12 space-y-6 md:space-y-8 bg-zinc-950">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
            {/* Título e Metadados */}
            <div className="space-y-4 max-w-2xl">
              <div className="flex flex-wrap items-center gap-3">
                <span className="text-xs bg-white/5 border border-white/10 px-3 py-1.5 rounded-md font-black text-[#00D1FF] uppercase tracking-wider">
                  {movie.category}
                </span>
                <span className="text-xs bg-zinc-900 border border-white/5 px-3 py-1.5 rounded-md text-gray-400 font-bold">
                  📅 {movie.year}
                </span>
                <span className="text-xs bg-zinc-900 border border-white/5 px-3 py-1.5 rounded-md text-[#FFD700] font-black flex items-center gap-1">
                  ⭐ {movie.rating ? movie.rating.toFixed(1) : '8.1'}
                </span>
                <span className="text-xs bg-[#00D1FF]/10 border border-[#00D1FF]/20 px-3 py-1.5 rounded-md text-[#00D1FF] font-black uppercase tracking-widest text-[9px]">
                  4K ULTRA HD
                </span>
              </div>

              <h1 className="text-3xl md:text-5xl font-black italic tracking-tighter text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.1)]">
                {movie.title}
              </h1>

              <p className="text-gray-400 text-xs md:text-sm leading-relaxed font-medium max-h-32 md:max-h-none overflow-y-auto pr-2 scrollbar-thin">
                {movie.description}
              </p>
            </div>

            {/* Poster Lateral opcional em telas grandes para dar um ar profissional de cinema */}
            <div className="hidden lg:block w-36 shrink-0 aspect-[2/3] rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
              <img src={movie.posterUrl} className="w-full h-full object-cover" alt={movie.title} />
            </div>
          </div>

          {/* Divisor Moderno Slim */}
          <div className="h-px w-full bg-white/5" />

          {/* Botões Principais de Ação */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 pt-2">
            
            {/* BOTÃO PLAY MASTER NEON */}
            <button
              onClick={() => onWatchFullMovie(movie)}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-3 px-10 py-5 bg-[#00D1FF] hover:bg-white text-black font-black uppercase text-xs md:text-sm tracking-widest rounded-full transition-all duration-300 transform hover:scale-[1.03] active:scale-95 shadow-[0_0_35px_rgba(0,209,255,0.4)] cursor-pointer group"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 fill-black group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
                <path d="M8 5v14l11-7z" />
              </svg>
              ASSISTIR FILME COMPLETO
            </button>

            {/* BOTÃO ADICIONAR/REMOVER DA MINHA LISTA */}
            <button
              onClick={() => onToggleFavorite(movie)}
              className={`flex items-center justify-center gap-2 px-6 py-5 rounded-full border text-xs md:text-sm font-black uppercase tracking-wider transition-all duration-300 active:scale-95 cursor-pointer ${
                isFavorite
                  ? 'bg-white/10 border-white/30 text-white hover:bg-white/20'
                  : 'bg-transparent border-white/10 text-white hover:border-[#00D1FF]/50 hover:text-[#00D1FF]'
              }`}
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill={isFavorite ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor">
                {isFavorite ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" />
                )}
              </svg>
              {isFavorite ? 'Remover da minha Lista' : 'Adicionar à minha Lista'}
            </button>

            {/* VOLTAR */}
            <button
              onClick={onClose}
              className="sm:ml-auto text-xs text-white/40 hover:text-white font-black uppercase tracking-widest text-center py-4 cursor-pointer hover:underline"
            >
              Voltar ao Catálogo
            </button>

          </div>
        </div>

      </div>
    </div>
  );
};

export default MovieDetailModal;
