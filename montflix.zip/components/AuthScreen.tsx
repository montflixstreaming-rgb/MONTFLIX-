
import React, { useState, useRef, useEffect } from 'react';
import { sendVerificationEmail } from '../services/emailService';
import { Security } from '../services/security';
import { Tv, Smartphone, Key, RefreshCw, CheckCircle2, ArrowLeft, Laptop, Gamepad2, Tablet, Clock, AlertTriangle, ShieldCheck, HelpCircle } from 'lucide-react';
import AdBanner from './AdBanner';

interface AuthScreenProps {
  onLogin: (user: { email: string; avatar: string | null }) => void;
  onStartPairing: () => void;
}

const getRegisteredAccounts = (): { [email: string]: string } => {
  const enc = localStorage.getItem('montflix_accounts_secure_db');
  if (!enc) return {};
  try {
    const dec = Security.decrypt(enc);
    return dec && typeof dec === 'object' ? dec : {};
  } catch {
    return {};
  }
};

const registerAccount = (email: string, pass: string) => {
  const accounts = getRegisteredAccounts();
  accounts[email.toLowerCase().trim()] = pass;
  localStorage.setItem('montflix_accounts_secure_db', Security.encrypt(accounts));
};

const AuthScreen: React.FC<AuthScreenProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showVerification, setShowVerification] = useState(false);
  const [generatedCode, setGeneratedCode] = useState('');
  const [verificationCode, setVerificationCode] = useState(['', '', '', '', '', '']);
  const [resendTimer, setResendTimer] = useState(0);
  
  // Pairing Mode States
  const [isPairingMode, setIsPairingMode] = useState(false);
  const [pairingStep, setPairingStep] = useState<'setup' | 'code' | 'success'>('setup');
  const [deviceType, setDeviceType] = useState<'tv' | 'mobile' | 'desktop' | 'console'>('tv');
  const [deviceName, setDeviceName] = useState('');
  const [pairingCode, setPairingCode] = useState('');
  const [pairingStatus, setPairingStatus] = useState<'pending' | 'success'>('pending');
  const [pairingTimer, setPairingTimer] = useState(600); // 10 minutos (600 segundos)
  
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    let interval: number;
    if (resendTimer > 0) {
      interval = window.setInterval(() => {
        setResendTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [resendTimer]);

  // Contagem regressiva do tempo do código de pareamento
  useEffect(() => {
    let timerInterval: number;
    if (isPairingMode && pairingStep === 'code' && pairingTimer > 0) {
      timerInterval = window.setInterval(() => {
        setPairingTimer((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(timerInterval);
  }, [isPairingMode, pairingStep, pairingTimer]);

  // Netflix-style pairing polling logic
  useEffect(() => {
    if (!isPairingMode || !pairingCode || pairingStep !== 'code') return;

    const interval = setInterval(() => {
      const pairedDataStr = localStorage.getItem(`montflix_pair_${pairingCode}`);
      if (pairedDataStr) {
        try {
          const decryptedUser = Security.decrypt(pairedDataStr);
          if (decryptedUser && decryptedUser.email) {
            setPairingStatus('success');
            setPairingStep('success');
            clearInterval(interval);
            setTimeout(() => {
              onLogin({
                email: decryptedUser.email,
                avatar: decryptedUser.avatar || null,
              });
              localStorage.removeItem(`montflix_pair_${pairingCode}`);
              localStorage.removeItem(`montflix_pair_req_${pairingCode}`);
            }, 2000);
          }
        } catch (err) {
          console.error("Erro ao descriptografar dados de pareamento:", err);
        }
      }
    }, 1500);

    return () => clearInterval(interval);
  }, [isPairingMode, pairingCode, pairingStep, onLogin]);

  const generateNewCode = () => {
    return Math.floor(100000 + Math.random() * 900000).toString();
  };

  const startPairingFlow = () => {
    setIsPairingMode(true);
    setPairingStep('setup');
    setDeviceName('');
    setDeviceType('tv');
  };

  const generatePairingCode = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    
    // Salvar metadados da solicitação para o ativador conseguir visualizar que aparelho está pedindo acesso
    const reqData = {
      code,
      type: deviceType,
      name: deviceName.trim() || getDefaultDeviceName(deviceType),
      createdAt: new Date().toISOString(),
    };
    
    localStorage.setItem(`montflix_pair_req_${code}`, Security.encrypt(reqData));
    
    setPairingCode(code);
    setPairingStatus('pending');
    setPairingTimer(600); // 10 minutos
    setPairingStep('code');
  };

  const getDefaultDeviceName = (type: string) => {
    switch (type) {
      case 'tv': return 'Smart TV Premium';
      case 'mobile': return 'Dispositivo Móvel';
      case 'desktop': return 'Computador de Mesa';
      case 'console': return 'Console de Video Game';
      default: return 'Novo Aparelho';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password) {
      setIsLoading(true);
      const safeEmail = Security.sanitize(email);
      const emailLower = safeEmail.toLowerCase().trim();

      const accounts = getRegisteredAccounts();
      const existingPass = accounts[emailLower];

      if (isRegistering) {
        if (existingPass) {
          setIsLoading(false);
          alert("Este e-mail já está cadastrado! Faça login com suas credenciais.");
          setIsRegistering(false);
          return;
        }

        const newCode = generateNewCode();
        setGeneratedCode(newCode);
        const sent = await sendVerificationEmail(safeEmail, newCode);
        setIsLoading(false);
        if (sent) {
          setShowVerification(true);
          setResendTimer(60);
        } else {
          alert("Falha ao enviar código. Verifique sua conexão.");
        }
      } else {
        // Se houver contas cadastradas e este e-mail já estiver cadastrado, valida a senha
        const keys = Object.keys(accounts);
        if (keys.length > 0 && existingPass !== undefined) {
          if (existingPass !== password) {
            setIsLoading(false);
            alert("Senha incorreta para esta conta. Tente novamente.");
            return;
          }
        }

        // Envia código de confirmação por e-mail para LOGIN também! (Altamente Profissional)
        const newCode = generateNewCode();
        setGeneratedCode(newCode);
        const sent = await sendVerificationEmail(safeEmail, newCode);
        setIsLoading(false);
        if (sent) {
          setShowVerification(true);
          setResendTimer(60);
        } else {
          completeLogin();
        }
      }
    }
  };

  const handleResend = async () => {
    if (resendTimer > 0) return;
    setIsLoading(true);
    const safeEmail = Security.sanitize(email);
    const newCode = generateNewCode();
    setGeneratedCode(newCode);
    await sendVerificationEmail(safeEmail, newCode);
    setIsLoading(false);
    setResendTimer(60);
    setVerificationCode(['', '', '', '', '', '']);
    inputRefs.current[0]?.focus();
  };

  const completeLogin = () => {
    const safeEmail = Security.sanitize(email);
    const userData = { 
      email: safeEmail, 
      avatar: `https://api.dicebear.com/7.x/pixel-art/svg?seed=${safeEmail.split('@')[0]}`,
    };
    onLogin(userData);
  };

  const handleCodeChange = (index: number, value: string) => {
    if (value.length > 1) value = value.slice(-1);
    if (!/^\d*$/.test(value)) return;
    const newCode = [...verificationCode];
    newCode[index] = value;
    setVerificationCode(newCode);
    if (value !== '' && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace' && verificationCode[index] === '' && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleVerify = () => {
    if (verificationCode.join('') === generatedCode) {
      setIsLoading(true);
      if (isRegistering) {
        registerAccount(email, password);
      } else {
        const accounts = getRegisteredAccounts();
        if (!accounts[email.toLowerCase().trim()]) {
          registerAccount(email, password);
        }
      }
      setTimeout(completeLogin, 800);
    } else {
      alert("Código incorreto.");
      setVerificationCode(['', '', '', '', '', '']);
      inputRefs.current[0]?.focus();
    }
  };

  return (
    <div className="relative min-h-screen w-full flex flex-col items-center justify-center bg-black font-sans overflow-hidden">
      <div className="absolute inset-0 z-0">
        <div 
          className="w-full h-full bg-cover bg-center opacity-20 scale-105"
          style={{ backgroundImage: 'url("https://images.unsplash.com/photo-1574267432553-4b4628081c31?q=80&w=2073&auto=format&fit=crop")' }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/80 to-black" />
      </div>

      <div className="relative z-10 w-full max-w-[450px] px-8 py-12 bg-black/40 rounded-[3rem] backdrop-blur-3xl border border-white/10 shadow-2xl">
        {isPairingMode ? (
          <div className="animate-in fade-in zoom-in-95 text-center space-y-6">
            <button 
              onClick={() => {
                if (pairingStep === 'code') {
                  setPairingStep('setup');
                } else {
                  setIsPairingMode(false);
                }
              }}
              className="flex items-center gap-2 text-white/40 hover:text-white/85 text-[10px] font-black uppercase tracking-widest transition-all mb-4"
            >
              <ArrowLeft className="w-3.5 h-3.5" /> {pairingStep === 'code' ? 'Ajustar Aparelho' : 'Voltar ao Login'}
            </button>

            {pairingStep === 'setup' ? (
              <div className="space-y-6 text-left">
                <div className="text-center space-y-2">
                  <div className="flex justify-center mb-2">
                    <div className="relative p-4 bg-[#00D1FF]/10 rounded-full border border-[#00D1FF]/20">
                      <Tv className="w-10 h-10 text-[#00D1FF] animate-pulse" />
                    </div>
                  </div>
                  <h2 className="text-2xl font-black text-white tracking-tighter uppercase">Configurar Aparelho</h2>
                  <p className="text-[10px] text-gray-400 leading-relaxed uppercase tracking-widest font-semibold max-w-sm mx-auto">
                    Escolha o tipo de dispositivo para iniciar o pareamento profissional
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-[9px] text-white/40 uppercase tracking-[0.2em] font-black block mb-2">1. Tipo de Dispositivo</label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setDeviceType('tv')}
                        className={`flex flex-col items-center justify-center p-4 rounded-2xl border text-center transition-all ${
                          deviceType === 'tv'
                            ? 'bg-[#00D1FF]/10 border-[#00D1FF] text-[#00D1FF]'
                            : 'bg-white/5 border-white/5 text-gray-400 hover:bg-white/10'
                        }`}
                      >
                        <Tv className="w-6 h-6 mb-2" />
                        <span className="text-[10px] font-black uppercase tracking-wider">Smart TV</span>
                      </button>
                      
                      <button
                        type="button"
                        onClick={() => setDeviceType('mobile')}
                        className={`flex flex-col items-center justify-center p-4 rounded-2xl border text-center transition-all ${
                          deviceType === 'mobile'
                            ? 'bg-[#00D1FF]/10 border-[#00D1FF] text-[#00D1FF]'
                            : 'bg-white/5 border-white/5 text-gray-400 hover:bg-white/10'
                        }`}
                      >
                        <Smartphone className="w-6 h-6 mb-2" />
                        <span className="text-[10px] font-black uppercase tracking-wider">Celular / Tab</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setDeviceType('desktop')}
                        className={`flex flex-col items-center justify-center p-4 rounded-2xl border text-center transition-all ${
                          deviceType === 'desktop'
                            ? 'bg-[#00D1FF]/10 border-[#00D1FF] text-[#00D1FF]'
                            : 'bg-white/5 border-white/5 text-gray-400 hover:bg-white/10'
                        }`}
                      >
                        <Laptop className="w-6 h-6 mb-2" />
                        <span className="text-[10px] font-black uppercase tracking-wider">Computador</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setDeviceType('console')}
                        className={`flex flex-col items-center justify-center p-4 rounded-2xl border text-center transition-all ${
                          deviceType === 'console'
                            ? 'bg-[#00D1FF]/10 border-[#00D1FF] text-[#00D1FF]'
                            : 'bg-white/5 border-white/5 text-gray-400 hover:bg-white/10'
                        }`}
                      >
                        <Gamepad2 className="w-6 h-6 mb-2" />
                        <span className="text-[10px] font-black uppercase tracking-wider">Console</span>
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="text-[9px] text-white/40 uppercase tracking-[0.2em] font-black block mb-2">2. Identificação do Aparelho (Apelido)</label>
                    <input
                      type="text"
                      maxLength={24}
                      value={deviceName}
                      onChange={(e) => setDeviceName(e.target.value)}
                      placeholder={`Ex: ${deviceType === 'tv' ? 'TV da Sala' : deviceType === 'mobile' ? 'Celular do Pai' : deviceType === 'desktop' ? 'Notebook Quarto' : 'PlayStation 5'}`}
                      className="w-full px-5 py-4 bg-white/5 border border-white/10 rounded-2xl text-white text-xs placeholder-white/20 focus:outline-none focus:border-[#00D1FF] transition-all font-semibold"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={generatePairingCode}
                    className="w-full bg-[#00D1FF] text-black font-black py-4 rounded-2xl text-xs uppercase tracking-[0.2em] shadow-lg shadow-[#00D1FF]/20 hover:scale-[1.01] active:scale-[0.98] transition-all flex items-center justify-center gap-2 mt-4"
                  >
                    Gerar Código de Conexão
                  </button>
                </div>
              </div>
            ) : pairingStep === 'code' ? (
              <div className="space-y-6">
                <div className="text-center space-y-2">
                  <span className="px-3 py-1 bg-white/5 border border-white/10 rounded-full text-[8px] font-black uppercase tracking-widest text-emerald-400">
                    🔒 Sessão Segura Encriptada
                  </span>
                  <h2 className="text-2xl font-black text-white tracking-tighter uppercase">Conectar Aparelho</h2>
                  <p className="text-[10px] text-gray-400 uppercase tracking-widest font-black leading-relaxed">
                    Você está ativando: <span className="text-white font-bold">{deviceName.trim() || getDefaultDeviceName(deviceType)}</span>
                  </p>
                </div>

                {pairingTimer <= 0 ? (
                  <div className="bg-red-500/10 border border-red-500/20 p-6 rounded-2xl text-center space-y-4">
                    <AlertTriangle className="w-10 h-10 text-red-500 mx-auto animate-bounce" />
                    <h4 className="text-sm font-black uppercase text-white tracking-wider">Código Expirado</h4>
                    <p className="text-[11px] text-gray-400 leading-relaxed font-semibold">O código de 10 minutos expirou por motivos de segurança. Por favor, gere um novo código.</p>
                    <button
                      type="button"
                      onClick={generatePairingCode}
                      className="bg-white hover:bg-gray-100 text-black text-[10px] font-black uppercase tracking-wider py-3 px-6 rounded-xl transition-all"
                    >
                      Gerar Novo Código
                    </button>
                  </div>
                ) : (
                  <>
                    {/* Pairing Code Display */}
                    <div className="bg-zinc-950/85 border border-white/5 py-6 px-4 rounded-3xl flex flex-col items-center justify-center space-y-4 shadow-inner relative overflow-hidden">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-[#00D1FF]/5 rounded-full blur-2xl" />
                      
                      <p className="text-[9px] text-white/30 uppercase tracking-[0.25em] font-black">Código de Ativação Único</p>
                      
                      <div className="flex gap-2 items-center">
                        {pairingCode.split('').map((char, index) => (
                          <span key={index} className="text-3xl font-black text-[#00D1FF] bg-white/5 border border-white/10 w-11 h-16 flex items-center justify-center rounded-xl shadow-lg ring-1 ring-white/5">
                            {char}
                          </span>
                        ))}
                      </div>

                      <div className="flex flex-col items-center gap-1">
                        <div className="flex items-center gap-1.5 text-[10px] text-[#00D1FF] font-black tracking-widest uppercase">
                          <RefreshCw className="w-3 h-3 animate-spin" /> Aguardando Ativação...
                        </div>
                        <div className="flex items-center gap-1 text-[9px] text-gray-500 font-bold uppercase tracking-wider">
                          <Clock className="w-3.5 h-3.5 text-gray-500" /> Expira em {Math.floor(pairingTimer / 60)}:{(pairingTimer % 60).toString().padStart(2, '0')}
                        </div>
                      </div>
                    </div>

                    {/* Step-by-Step Interactive Guide */}
                    <div className="text-left bg-gradient-to-b from-white/[0.04] to-transparent rounded-3xl p-6 space-y-4 border border-white/5 relative">
                      <h4 className="text-[10px] font-black text-[#00D1FF] uppercase tracking-[0.2em] border-b border-white/5 pb-2">Como Conectar:</h4>
                      
                      <div className="space-y-4">
                        <div className="flex gap-3 items-start">
                          <span className="w-6 h-6 flex items-center justify-center bg-[#00D1FF]/10 text-[#00D1FF] border border-[#00D1FF]/20 font-black rounded-xl text-xs shrink-0 shadow-md">1</span>
                          <p className="text-xs text-white/70 font-semibold leading-relaxed">
                            No celular, TV ou computador <span className="text-[#00D1FF] font-bold">onde você já está logado</span>, abra as Configurações do seu Perfil.
                          </p>
                        </div>
                        <div className="flex gap-3 items-start">
                          <span className="w-6 h-6 flex items-center justify-center bg-[#00D1FF]/10 text-[#00D1FF] border border-[#00D1FF]/20 font-black rounded-xl text-xs shrink-0 shadow-md">2</span>
                          <p className="text-xs text-white/70 font-semibold leading-relaxed">
                            Vá na aba <span className="text-white font-bold">"📺 Ativar Aparelho"</span> e digite o código de 6 dígitos acima.
                          </p>
                        </div>
                        <div className="flex gap-3 items-start">
                          <span className="w-6 h-6 flex items-center justify-center bg-[#00D1FF]/10 text-[#00D1FF] border border-[#00D1FF]/20 font-black rounded-xl text-xs shrink-0 shadow-md">3</span>
                          <p className="text-xs text-white/70 font-semibold leading-relaxed">
                            Pronto! O sistema vai conectar este aparelho instantaneamente em <span className="text-white font-bold">sua conta dividida</span>.
                          </p>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <div className="py-12 px-6 bg-emerald-500/10 border border-emerald-500/20 rounded-3xl space-y-5 animate-in zoom-in-95 duration-500 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-b from-emerald-500/5 to-transparent" />
                <div className="relative z-10 space-y-4">
                  <div className="w-20 h-20 bg-emerald-500/20 border border-emerald-500/40 rounded-full flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/10 animate-bounce">
                    <ShieldCheck className="w-10 h-10 text-emerald-400" />
                  </div>
                  <h3 className="text-2xl font-black text-white uppercase tracking-tighter">Aparelho Ativado!</h3>
                  <p className="text-xs text-white/60 font-semibold leading-relaxed max-w-sm mx-auto">
                    Conexão estabelecida e autenticada de ponta a ponta. Sincronizando perfis e preferências...
                  </p>
                  <div className="pt-2">
                    <span className="text-[9px] font-black text-emerald-400 uppercase tracking-widest bg-emerald-500/10 border border-emerald-500/20 py-2 px-4 rounded-full">
                      Acesso Seguro Concedido
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        ) : !showVerification ? (
          <div className="animate-in fade-in slide-in-from-bottom-4">
            <h1 className="text-4xl font-black text-[#00D1FF] tracking-tighter mb-10 text-center">MONTFLIX</h1>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <input 
                type="email" 
                required 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                placeholder="E-mail" 
                className="w-full px-6 py-4 bg-white/5 border border-white/10 rounded-2xl text-white focus:outline-none focus:border-[#00D1FF] transition-all" 
              />
              <input 
                type="password" 
                required 
                value={password} 
                onChange={(e) => setPassword(e.target.value)} 
                placeholder="Senha" 
                className="w-full px-6 py-4 bg-white/5 border border-white/10 rounded-2xl text-white focus:outline-none focus:border-[#00D1FF] transition-all" 
              />
              <button 
                type="submit" 
                disabled={isLoading} 
                className="w-full bg-[#00D1FF] text-black font-black py-5 rounded-2xl uppercase text-xs tracking-[0.3em] shadow-lg hover:scale-[1.02] active:scale-95 transition-all"
              >
                {isLoading ? 'Carregando...' : (isRegistering ? 'Criar Conta' : 'Entrar')}
              </button>
            </form>

            <div className="flex flex-col items-center gap-4 mt-6 pt-4 border-t border-white/5">
              <button 
                onClick={startPairingFlow}
                className="w-full flex items-center justify-center gap-3 bg-white/5 hover:bg-white/10 text-white font-black py-4 px-6 rounded-2xl border border-white/10 hover:border-white/25 text-[10px] uppercase tracking-wider transition-all"
              >
                <Tv className="w-4 h-4 text-[#00D1FF]" /> Parear TV / Outro Aparelho
              </button>

              <button 
                onClick={() => setIsRegistering(!isRegistering)} 
                className="text-gray-500 text-[10px] font-black uppercase tracking-widest hover:text-white transition-colors"
              >
                {isRegistering ? 'Já tenho conta' : 'Novo por aqui? Criar conta'}
              </button>
            </div>
          </div>
        ) : (
          <div className="animate-in fade-in zoom-in-95 text-center">
             <h2 className="text-2xl font-black text-white mb-2 tracking-tighter uppercase">Verificação</h2>
             <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mb-10">Enviamos um código para seu e-mail</p>
             <div className="flex justify-between gap-2 mb-10">
                {verificationCode.map((digit, idx) => (
                  <input 
                    key={idx} 
                    ref={(el) => { inputRefs.current[idx] = el; }} 
                    type="text" 
                    value={digit} 
                    onChange={(e) => handleCodeChange(idx, e.target.value)} 
                    onKeyDown={(e) => handleKeyDown(idx, e)} 
                    className="w-12 h-16 bg-white/5 border border-white/10 rounded-2xl text-center text-2xl font-black text-[#00D1FF] focus:outline-none focus:border-[#00D1FF] shadow-inner" 
                  />
                ))}
             </div>
             <button 
              onClick={handleVerify} 
              disabled={isLoading} 
              className="w-full bg-white text-black font-black py-5 rounded-2xl uppercase text-xs tracking-[0.4em] transition-all"
             >
              Verificar Código
             </button>
             <button 
              onClick={handleResend} 
              disabled={resendTimer > 0} 
              className="mt-8 text-gray-500 text-[10px] uppercase font-black tracking-widest hover:text-white"
             >
              {resendTimer > 0 ? `Reenviar em ${resendTimer}s` : 'Reenviar código'}
             </button>
          </div>
        )}
      </div>

      {/* AdSense Verification Block */}
      <div className="relative z-10 mt-12 w-full max-w-[450px] opacity-10 hover:opacity-100 transition-opacity">
        <AdBanner slot="auto" format="auto" />
      </div>
    </div>
  );
};

export default AuthScreen;
