import React, { useState, useEffect } from 'react';
import { Security } from '../services/security';
import { Movie } from '../services/types';
import { Plus, Edit2, Trash2, Check, ArrowLeft, LogOut, UserCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  myList: Movie[];
  history: Movie[];
}

interface ProfileSelectionProps {
  userEmail: string;
  onSelectProfile: (profile: UserProfile) => void;
  onLogout: () => void;
}

const AVATAR_PRESETS = [
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=Felix',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=Ane',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=Jack',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=Mimi',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=Zoe',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=Leo',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=Maya',
  'https://api.dicebear.com/7.x/pixel-art/svg?seed=Toby',
];

const ProfileSelection: React.FC<ProfileSelectionProps> = ({ userEmail, onSelectProfile, onLogout }) => {
  const [profiles, setProfiles] = useState<UserProfile[]>([]);
  const [isEditingMode, setIsEditingMode] = useState(false);
  const [editingProfile, setEditingProfile] = useState<UserProfile | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [tempName, setTempName] = useState('');
  const [tempAvatar, setTempAvatar] = useState(AVATAR_PRESETS[0]);

  const storageKey = `montflix_profiles_${userEmail.toLowerCase().trim()}`;

  // Load profiles
  useEffect(() => {
    const savedEnc = localStorage.getItem(storageKey);
    if (savedEnc) {
      try {
        const decrypted = Security.decrypt(savedEnc);
        if (Array.isArray(decrypted) && decrypted.length > 0) {
          setProfiles(decrypted);
          return;
        }
      } catch (err) {
        console.error('Error loading profiles:', err);
      }
    }

    // Default profile if none exists
    const defaultProfile: UserProfile = {
      id: 'default',
      name: userEmail.split('@')[0],
      avatar: AVATAR_PRESETS[0],
      myList: [],
      history: [],
    };
    const initialProfiles = [defaultProfile];
    setProfiles(initialProfiles);
    localStorage.setItem(storageKey, Security.encrypt(initialProfiles));
  }, [userEmail, storageKey]);

  const saveProfilesToStorage = (updatedProfiles: UserProfile[]) => {
    setProfiles(updatedProfiles);
    localStorage.setItem(storageKey, Security.encrypt(updatedProfiles));
  };

  const handleCreateProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tempName.trim()) return;

    const newProfile: UserProfile = {
      id: crypto.randomUUID(),
      name: tempName.trim(),
      avatar: tempAvatar,
      myList: [],
      history: [],
    };

    const updated = [...profiles, newProfile];
    saveProfilesToStorage(updated);
    setIsCreating(false);
    setTempName('');
    setTempAvatar(AVATAR_PRESETS[Math.floor(Math.random() * AVATAR_PRESETS.length)]);
  };

  const handleSaveEditProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProfile || !tempName.trim()) return;

    const updated = profiles.map((p) => {
      if (p.id === editingProfile.id) {
        return { ...p, name: tempName.trim(), avatar: tempAvatar };
      }
      return p;
    });

    saveProfilesToStorage(updated);
    setEditingProfile(null);
    setTempName('');
  };

  const handleDeleteProfile = (profileId: string) => {
    if (profiles.length <= 1) {
      alert('Você precisa manter pelo menos um perfil em sua conta.');
      return;
    }
    if (confirm('Tem certeza de que deseja excluir este perfil? Todos os favoritos e histórico serão perdidos.')) {
      const updated = profiles.filter((p) => p.id !== profileId);
      saveProfilesToStorage(updated);
      setEditingProfile(null);
      setTempName('');
    }
  };

  const startEdit = (profile: UserProfile) => {
    setEditingProfile(profile);
    setTempName(profile.name);
    setTempAvatar(profile.avatar);
  };

  const startCreate = () => {
    setIsCreating(true);
    setTempName('');
    setTempAvatar(AVATAR_PRESETS[Math.floor(Math.random() * AVATAR_PRESETS.length)]);
  };

  return (
    <div className="min-h-screen bg-black flex flex-col items-center justify-center font-sans px-4 select-none relative overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-[#00D1FF]/5 blur-[120px] rounded-full pointer-events-none" />

      {/* Main Container */}
      <div className="relative z-10 w-full max-w-4xl text-center space-y-12 py-12">
        <AnimatePresence mode="wait">
          {!isCreating && !editingProfile ? (
            <motion.div
              key="selection"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
              className="space-y-10"
            >
              <div className="space-y-2">
                <h1 className="text-3xl md:text-5xl font-black text-white tracking-tighter uppercase">
                  {isEditingMode ? 'Gerenciar Perfis' : 'Quem está assistindo?'}
                </h1>
                <p className="text-xs text-white/40 tracking-[0.25em] font-black uppercase">
                  {isEditingMode ? 'Escolha um perfil para editar ou gerenciar' : 'Selecione um perfil para entrar na plataforma'}
                </p>
              </div>

              {/* Profiles Grid */}
              <div className="flex flex-wrap justify-center items-center gap-8 md:gap-12 py-8">
                {profiles.map((profile) => (
                  <div
                    key={profile.id}
                    onClick={() => {
                      if (isEditingMode) {
                        startEdit(profile);
                      } else {
                        onSelectProfile(profile);
                      }
                    }}
                    className="group flex flex-col items-center space-y-4 cursor-pointer relative"
                  >
                    <div className="relative w-28 h-28 md:w-32 md:h-32 rounded-3xl overflow-hidden border-4 border-transparent group-hover:border-[#00D1FF] transition-all duration-300 shadow-lg group-hover:shadow-[0_0_25px_rgba(0,209,255,0.4)] transform group-hover:scale-105">
                      <img
                        src={profile.avatar}
                        alt={profile.name}
                        className="w-full h-full object-cover bg-zinc-900"
                        referrerPolicy="no-referrer"
                      />
                      {isEditingMode && (
                        <div className="absolute inset-0 bg-black/60 flex items-center justify-center backdrop-blur-xs">
                          <Edit2 className="w-8 h-8 text-white/80 group-hover:text-white group-hover:scale-110 transition-transform" />
                        </div>
                      )}
                    </div>
                    <span className="text-sm md:text-base font-black uppercase tracking-wider text-gray-400 group-hover:text-white transition-colors duration-300">
                      {profile.name}
                    </span>
                  </div>
                ))}

                {/* Add Profile Button */}
                {profiles.length < 5 && (
                  <div
                    onClick={startCreate}
                    className="group flex flex-col items-center space-y-4 cursor-pointer"
                  >
                    <div className="w-28 h-28 md:w-32 md:h-32 rounded-3xl border-4 border-dashed border-white/20 group-hover:border-white/50 bg-white/5 group-hover:bg-white/10 flex items-center justify-center transition-all duration-300 transform group-hover:scale-105">
                      <Plus className="w-10 h-10 text-white/40 group-hover:text-white/80 transition-colors" />
                    </div>
                    <span className="text-sm md:text-base font-black uppercase tracking-wider text-gray-500 group-hover:text-gray-300 transition-colors">
                      Adicionar
                    </span>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
                <button
                  onClick={() => setIsEditingMode(!isEditingMode)}
                  className={`px-8 py-3.5 rounded-2xl border text-xs font-black uppercase tracking-widest transition-all ${
                    isEditingMode
                      ? 'border-[#00D1FF] bg-[#00D1FF]/10 text-[#00D1FF] hover:bg-[#00D1FF]/20 shadow-[0_0_15px_rgba(0,209,255,0.2)]'
                      : 'border-white/20 text-gray-400 hover:text-white hover:border-white/40'
                  }`}
                >
                  {isEditingMode ? 'Concluir' : 'Gerenciar Perfis'}
                </button>

                <button
                  onClick={onLogout}
                  className="px-8 py-3.5 rounded-2xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white border border-white/5 hover:border-white/10 text-xs font-black uppercase tracking-widest transition-all flex items-center gap-2"
                >
                  <LogOut className="w-4 h-4" /> Sair da Conta
                </button>
              </div>
            </motion.div>
          ) : (
            /* Create or Edit Screen */
            <motion.div
              key="form"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.3 }}
              className="max-w-xl mx-auto bg-zinc-950/40 border border-white/10 rounded-[3rem] p-8 md:p-12 backdrop-blur-3xl space-y-8 text-left shadow-2xl"
            >
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    setIsCreating(false);
                    setEditingProfile(null);
                  }}
                  className="p-2 bg-white/5 hover:bg-white/10 rounded-xl border border-white/5 hover:border-white/10 text-white/60 hover:text-white transition-colors"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <h2 className="text-xl md:text-2xl font-black text-white uppercase tracking-tighter">
                  {isCreating ? 'Adicionar Novo Perfil' : 'Editar Perfil'}
                </h2>
              </div>

              <form onSubmit={isCreating ? handleCreateProfile : handleSaveEditProfile} className="space-y-8">
                {/* Profile Avatar Selection & Name Row */}
                <div className="flex flex-col sm:flex-row items-center gap-8 bg-black/40 border border-white/5 p-6 rounded-3xl">
                  {/* Current Selected Avatar */}
                  <div className="relative w-24 h-24 rounded-2xl overflow-hidden border-2 border-[#00D1FF] shadow-lg shadow-[#00D1FF]/20 shrink-0">
                    <img src={tempAvatar} alt="Preview Avatar" className="w-full h-full object-cover bg-zinc-900" referrerPolicy="no-referrer" />
                  </div>

                  <div className="w-full space-y-2">
                    <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">
                      Nome do Perfil
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Nome de quem vai assistir"
                      value={tempName}
                      onChange={(e) => setTempName(e.target.value)}
                      maxLength={15}
                      className="w-full bg-zinc-900/60 border border-white/10 rounded-2xl px-5 py-4 text-white text-sm font-bold focus:outline-none focus:border-[#00D1FF] transition-all"
                    />
                  </div>
                </div>

                {/* Avatar Presets Grid */}
                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-widest text-gray-400">
                    Escolha um Avatar Personalizado
                  </label>
                  <div className="grid grid-cols-4 gap-4 p-4 bg-black/40 border border-white/5 rounded-3xl">
                    {AVATAR_PRESETS.map((preset) => (
                      <div
                        key={preset}
                        onClick={() => setTempAvatar(preset)}
                        className={`relative aspect-square rounded-xl overflow-hidden cursor-pointer border-2 transition-all ${
                          tempAvatar === preset
                            ? 'border-[#00D1FF] scale-105 shadow-[0_0_15px_rgba(0,209,255,0.3)]'
                            : 'border-transparent hover:border-white/30'
                        }`}
                      >
                        <img src={preset} alt="Preset Option" className="w-full h-full object-cover bg-zinc-900" referrerPolicy="no-referrer" />
                        {tempAvatar === preset && (
                          <div className="absolute top-1 right-1 bg-[#00D1FF] text-black rounded-full p-0.5 border border-black/40 shadow-sm">
                            <Check className="w-3 h-3 stroke-[3]" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center justify-between gap-4 pt-4 border-t border-white/5">
                  {editingProfile && (
                    <button
                      type="button"
                      onClick={() => handleDeleteProfile(editingProfile.id)}
                      className="flex items-center gap-2 text-rose-500 hover:text-rose-400 font-bold text-xs uppercase tracking-wider py-3 px-4 rounded-xl hover:bg-rose-500/10 transition-all"
                    >
                      <Trash2 className="w-4 h-4" /> Excluir Perfil
                    </button>
                  )}

                  <div className="flex gap-3 ml-auto">
                    <button
                      type="button"
                      onClick={() => {
                        setIsCreating(false);
                        setEditingProfile(null);
                      }}
                      className="px-6 py-3 rounded-2xl bg-white/5 hover:bg-white/10 text-gray-400 hover:text-white border border-white/5 hover:border-white/10 text-xs font-black uppercase tracking-wider transition-all"
                    >
                      Cancelar
                    </button>

                    <button
                      type="submit"
                      disabled={!tempName.trim()}
                      className="px-8 py-3 rounded-2xl bg-[#00D1FF] hover:bg-[#00D1FF]/90 text-black font-black text-xs uppercase tracking-wider transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      Salvar
                    </button>
                  </div>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default ProfileSelection;
