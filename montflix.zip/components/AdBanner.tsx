
import React, { useEffect, useRef, useState } from 'react';

interface AdBannerProps {
  slot?: string;
  format?: 'auto' | 'fluid' | 'rectangle';
  style?: React.CSSProperties;
}

declare global {
  interface Window {
    adsbygoogle: any[];
  }
}

const AdBanner: React.FC<AdBannerProps> = ({ 
  slot = "auto", 
  format = "auto", 
  style = { display: 'block', minWidth: '250px', minHeight: '100px' } 
}) => {
  const adRef = useRef<HTMLDivElement>(null);
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    if (isInitialized) return;

    const timer = setTimeout(() => {
      if (adRef.current && adRef.current.offsetWidth > 0) {
        try {
          (window.adsbygoogle = window.adsbygoogle || []).push({});
          setIsInitialized(true);
        } catch (e) {
          console.error("AdSense error:", e);
        }
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [isInitialized]);

  return (
    <div ref={adRef} className="ad-container w-full overflow-hidden flex justify-center items-center bg-white/5 rounded-xl min-h-[100px]">
      <ins
        className="adsbygoogle"
        style={style}
        data-ad-client="ca-pub-4752617241621754"
        data-ad-slot={slot}
        data-ad-format={format}
        data-full-width-responsive="true"
      />
    </div>
  );
};

export default AdBanner;
