
import React, { useState, useEffect } from 'react';
import { Movie } from '../services/types';

interface HeroProps {
  movies: Movie[];
  onWatchNow: (m: Movie) => void;
  currentLang: string;
}

const Hero: React.FC<HeroProps> = ({ movies, onWatchNow }) => {
  const [index, setIndex] = useState(0);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);

  // Background estético para o slide do App
  const APP_BG = "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?q=80&w=2000&auto=format&fit=crop";

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  }, []);

  const totalSlides = movies.length + 1;
  const isAppSlide = index === movies.length;
  const movie = movies[index];

  useEffect(() => {
    if (!movies || movies.length === 0) return;
    const timer = setInterval(() => {
      setIndex(prev => (prev + 1) % totalSlides);
    }, 8000);
    return () => clearInterval(timer);
  }, [movies, totalSlides]);

  const handleInstallApp = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') setDeferredPrompt(null);
    } else {
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
      if (isIOS) {
        alert("Para instalar no iPhone:\n1. Toque no ícone de 'Compartilhar' (seta para cima)\n2. Role e toque em 'Adicionar à Tela de Início'.");
      } else {
        alert("Para baixar: Abra o menu do seu navegador (três pontinhos) e selecione 'Instalar Aplicativo'.");
      }
    }
  };

  if (!movie && !isAppSlide) return <div className="h-[90vh] w-full bg-black" />;

  return (
    <div className="relative h-[90vh] md:h-screen w-full flex items-center px-6 md:px-14 lg:px-24 overflow-hidden bg-black">
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-black/60 z-10" />
        {isAppSlide ? (
          <div className="w-full h-full bg-[#050505]">
             <img src={APP_BG} className="absolute inset-0 w-full h-full object-cover opacity-30 blur-[2px]" alt="" />
             <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent" />
          </div>
        ) : (
          <img 
            key={movie.id}
            src={movie.backdropUrl} 
            className="w-full h-full object-cover transition-opacity duration-1000 animate-ken-burns" 
            alt="" 
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-r from-[#050505] via-[#050505]/60 to-transparent z-20" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#050505] via-transparent to-transparent z-20" />
      </div>

      <div className="relative z-30 max-w-5xl space-y-6 md:space-y-10 animate-in fade-in duration-700">
        {isAppSlide ? (
          <>
            <div className="flex items-center gap-4">
              <div className="bg-[#FFD700] text-black px-4 py-1.5 rounded-xl shadow-[0_0_30px_rgba(255,215,0,0.4)]">
                <span className="text-[10px] font-black uppercase tracking-widest">Disponível para Android & iOS</span>
              </div>
              <span className="text-white/40 text-[10px] font-black uppercase tracking-[0.4em]">Mobile Experience</span>
            </div>

            <div className="flex flex-col items-start gap-8">
               <h1 className="text-6xl md:text-[8rem] font-black uppercase tracking-tighter leading-[0.85] text-white">
                 BAIXE O APP <br/>
                 <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FFD700] to-[#B8860B] drop-shadow-[0_0_20px_rgba(184,134,11,0.5)]">MONTFLIX PRO</span>
               </h1>
               
               <p className="text-white/60 text-lg md:text-2xl max-w-2xl font-bold uppercase tracking-widest leading-relaxed">
                 Transforme seu celular em um cinema portátil. Instalação rápida, sem anúncios e com todos os canais ao vivo.
               </p>

               <div className="flex flex-col md:flex-row gap-6 w-full md:w-auto">
                 <button 
                  onClick={handleInstallApp}
                  className="group relative bg-white text-black font-black px-12 md:px-20 py-6 md:py-8 rounded-[2.5rem] hover:scale-105 transition-all transform active:scale-95 text-xs md:text-xl uppercase tracking-[0.3em] flex items-center justify-center gap-6 shadow-[0_20px_60px_rgba(255,255,255,0.1)] overflow-hidden"
                 >
                   <div className="absolute inset-0 bg-gradient-to-r from-transparent via-black/5 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                   <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 24 24" fill="currentColor">
                     <path d="M17.523 15.341c-.551 0-1 .449-1 1 0 .552.449 1 1 1h1.231c.139 0 .25.111.25.25v1.231c0 .551.449 1 1 1s1-.449 1-1v-1.231c0-.689-.561-1.25-1.25-1.25h-1.231zM11.5 2C6.806 2 3 5.806 3 10.5S6.806 19 11.5 19 20 15.194 20 10.5 16.194 2 11.5 2zm0 15c-2.481 0-4.5-2.019-4.5-4.5S9.019 8 11.5 8 16 10.019 16 12.5 13.981 17 11.5 17z"/>
                   </svg>
                   Instalar Agora
                 </button>

                 <div className="flex items-center gap-4 px-8 py-6 bg-black/40 border border-white/5 rounded-[2.5rem] backdrop-blur-xl">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/d/d7/Google_Play_Store_logo_2022.svg" className="h-6 opacity-60 grayscale hover:grayscale-0 transition-all" alt="Play Store" />
                    <img src="https://upload.wikimedia.org/wikipedia/commons/6/67/App_Store_%28iOS%29.svg" className="h-6 opacity-60 grayscale hover:grayscale-0 transition-all" alt="App Store" />
                    <span className="text-[10px] text-white/20 font-black uppercase tracking-widest">Verificado</span>
                 </div>
               </div>
            </div>
          </>
        ) : (
          <>
            <div className="flex items-center gap-4">
              <div className="flex items-center bg-[#00D1FF] text-black px-4 py-1.5 rounded-xl shadow-[0_0_30px_rgba(0,209,255,0.4)]">
                <span className="text-[10px] font-black uppercase tracking-widest">Estreia Exclusiva</span>
              </div>
              <span className="text-white/40 text-[10px] font-black uppercase tracking-[0.4em]">Cinematics™</span>
            </div>
            
            <h1 className="text-5xl md:text-8xl lg:text-[10rem] font-black uppercase tracking-tighter leading-[0.75] drop-shadow-[0_15px_45px_rgba(0,0,0,0.8)]">
              {movie.title}
            </h1>
            
            <div className="flex items-center gap-6 text-sm md:text-lg font-bold text-white/80">
              <div className="flex items-center gap-2">
                <span className="text-[#00D1FF] text-2xl font-black">★</span>
                <span className="tracking-tighter">{movie.rating.toFixed(1)}</span>
              </div>
              <span className="w-1.5 h-1.5 bg-white/20 rounded-full" />
              <span className="tracking-widest">{movie.year}</span>
              <span className="w-1.5 h-1.5 bg-white/20 rounded-full" />
              <span className="border border-white/20 px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest">4K ULTRA HD</span>
            </div>

            <p className="text-white/50 text-base md:text-2xl max-w-3xl line-clamp-3 leading-relaxed font-medium">
              {movie.description}
            </p>

            <div className="flex flex-wrap gap-6 pt-10">
              <button 
                onClick={() => onWatchNow(movie)} 
                className="group relative bg-white text-black font-black px-12 md:px-20 py-6 md:py-8 rounded-[2rem] hover:bg-[#00D1FF] transition-all transform active:scale-95 text-xs md:text-2xl uppercase tracking-[0.2em] flex items-center gap-6 overflow-hidden shadow-2xl"
              >
                 <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 md:h-12 md:w-12 fill-black" viewBox="0 0 24 24">
                   <path d="M8 5v14l11-7z" />
                 </svg>
                 Dar o Play
              </button>
            </div>
          </>
        )}
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-40 flex gap-3">
        {Array.from({ length: totalSlides }).map((_, i) => (
          <div 
            key={i} 
            className={`h-1.5 rounded-full transition-all duration-500 ${i === index ? 'w-10 bg-[#FFD700]' : 'w-2 bg-white/20'}`} 
          />
        ))}
      </div>

      <style>{`
        @keyframes ken-burns {
          0% { transform: scale(1.05) translate(0,0); }
          100% { transform: scale(1.15) translate(-1%, -1%); }
        }
        .animate-ken-burns {
          animation: ken-burns 20s ease-in-out infinite alternate;
        }
      `}</style>
    </div>
  );
};
export default Hero;
