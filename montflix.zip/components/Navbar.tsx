
import React from 'react';
import { Language } from '../translations';

interface NavbarProps {
  onSearchChange: (query: string) => void;
  onOpenSettings: () => void;
  userAvatar: string | null;
  currentLang: Language;
  currentView: string;
  onViewChange: (view: string) => void;
  currentUserEmail: string;
}

const Navbar: React.FC<NavbarProps> = ({ 
  onSearchChange, onOpenSettings, userAvatar, currentView, onViewChange
}) => {
  const [localQuery, setLocalQuery] = React.useState('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setLocalQuery(val);
    onSearchChange(val);
  };

  return (
    <nav className="fixed top-0 w-full z-[100] bg-black/60 backdrop-blur-3xl border-b border-white/5 px-6 md:px-20 py-8 flex items-center justify-between">
      {/* LOGO GIGANTE MASTER NEON */}
      <div 
        onClick={() => onViewChange('home')}
        className="cursor-pointer select-none group flex items-center gap-6 shrink-0"
      >
        <span className="text-4xl md:text-8xl font-black italic tracking-tighter text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.4)] transition-all">
          MONT<span className="text-[#00D1FF] drop-shadow-[0_0_30px_#00D1FF]">FLIX</span>
        </span>
      </div>

      {/* NAVEGAÇÃO SLIM PROFISSIONAL */}
      <div className="hidden sm:flex items-center gap-8 md:gap-16 bg-white/5 border border-white/10 px-8 py-3 rounded-full shrink-0">
        <button 
          onClick={() => onViewChange('home')}
          className="relative group outline-none"
        >
          <span className={`text-[10px] md:text-[12px] font-black uppercase tracking-[0.5em] transition-all duration-300 ${
            currentView === 'home' || currentView === 'movies'
              ? 'text-white' 
              : 'text-white/20 hover:text-white/60'
          }`}>
            Filmes
          </span>
          {(currentView === 'home' || currentView === 'movies') && (
            <div className="absolute -bottom-2 left-0 right-0 h-[3px] bg-[#00D1FF] shadow-[0_0_15px_#00D1FF] rounded-full" />
          )}
        </button>

        <button 
          onClick={() => onViewChange('iptv')}
          className="relative group outline-none"
        >
          <span className={`text-[10px] md:text-[12px] font-black uppercase tracking-[0.5em] transition-all duration-300 ${
            currentView === 'iptv' 
              ? 'text-white' 
              : 'text-white/20 hover:text-white/60'
          }`}>
            Ao Vivo
          </span>
          {currentView === 'iptv' && (
            <div className="absolute -bottom-2 left-0 right-0 h-[3px] bg-[#00D1FF] shadow-[0_0_15px_#00D1FF] rounded-full" />
          )}
        </button>
      </div>

      {/* PERFIL DESIGNER E BUSCA */}
      <div className="flex items-center gap-4 md:gap-6">
        <div className="relative flex items-center">
          <input 
            type="text" 
            value={localQuery}
            onChange={handleInputChange}
            placeholder="Buscar filmes..."
            className="bg-white/5 border border-white/10 text-white font-medium text-[10px] md:text-xs px-4 py-2 md:px-5 md:py-2.5 rounded-full outline-none w-28 sm:w-40 md:w-64 lg:w-72 focus:w-36 sm:focus:w-52 md:focus:w-80 focus:border-[#00D1FF] focus:ring-2 focus:ring-[#00D1FF]/10 transition-all duration-300 placeholder-white/30"
          />
          <svg xmlns="http://www.w3.org/2000/svg" className="absolute right-3 md:right-4 h-3 w-3 md:h-4 md:w-4 text-white/40 pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </div>

        <button 
          onClick={onOpenSettings}
          className="w-10 h-10 md:w-16 md:h-16 rounded-xl md:rounded-[1.5rem] overflow-hidden border border-white/10 hover:border-[#00D1FF]/50 transition-all active:scale-95 bg-zinc-900 shadow-2xl group shrink-0"
        >
          {userAvatar ? (
            <img src={userAvatar} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt="User" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-xl">👤</div>
          )}
        </button>
      </div>
    </nav>
  );
};

export default Navbar;
