
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import MovieRow from './components/MovieRow';
import MovieCard from './components/MovieCard';
import SettingsModal from './components/SettingsModal';
import AuthScreen from './components/AuthScreen';
import PlanSelection from './components/PlanSelection';
import NotificationToast from './components/NotificationToast';
import VideoPlayer from './components/VideoPlayer';
import IPTVView from './components/IPTVView';
import IPTVPlayer from './components/IPTVPlayer';
import MovieDetailModal from './components/MovieDetailModal';
import BottomNav from './components/BottomNav';
import ProfileSelection, { UserProfile } from './components/ProfileSelection';
import { Security } from './services/security'; 
import { Movie, IPTVChannel } from './services/types';
import { Language } from './translations';
import { tmdbService } from './services/tmdbService';

const GENRES = [
  { id: 28, name: 'Ação 💥' },
  { id: 35, name: 'Comédia 🍿' },
  { id: 27, name: 'Terror 👻' },
  { id: 878, name: 'Ficção Científica 🛸' },
  { id: 18, name: 'Drama 🎭' },
  { id: 16, name: 'Animação 🧸' },
  { id: 53, name: 'Suspense 🤫' },
  { id: 10749, name: 'Romance 💖' }
];

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<any | null>(null);
  const [activeProfile, setActiveProfile] = useState<UserProfile | null>(null);
  const [currentView, setCurrentView] = useState('home');
  
  const cached = tmdbService.getCachedData();
  const [sections, setSections] = useState(cached || {
    trending: [], popular: [], nowPlaying: [], upcoming: [], topRated: []
  });
  
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Movie[]>([]);
  const [searchLoading, setSearchLoading] = useState(false);
  
  const [selectedGenre, setSelectedGenre] = useState<{ id: number; name: string } | null>(null);
  const [genreMovies, setGenreMovies] = useState<Movie[]>([]);
  const [genrePage, setGenrePage] = useState(1);
  const [genreLoading, setGenreLoading] = useState(false);

  const [language, setLanguage] = useState<Language>('pt');
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [activeMovie, setActiveMovie] = useState<Movie | null>(null);
  const [detailMovie, setDetailMovie] = useState<Movie | null>(null);
  const [activeChannel, setActiveChannel] = useState<IPTVChannel | null>(null);
  const [myList, setMyList] = useState<Movie[]>([]);

  useEffect(() => {
    const savedSessionEnc = localStorage.getItem('montflix_session_secure');
    if (savedSessionEnc) {
      const user = Security.decrypt(savedSessionEnc);
      if (user) {
        const emailLower = user.email ? user.email.toLowerCase().trim() : '';
        if (emailLower === 'meudrivu@gmail.com' || emailLower === 'meudrivu@gmail.coml') {
          user.plan = 'premium';
        }
        setCurrentUser(user);
      }
    }

    const savedProfileEnc = localStorage.getItem('montflix_active_profile_secure');
    if (savedProfileEnc) {
      try {
        const profile = Security.decrypt(savedProfileEnc);
        if (profile) {
          setActiveProfile(profile);
          setMyList(profile.myList || []);
        }
      } catch (e) {
        console.error("Error loading saved profile:", e);
      }
    } else {
      const savedListEnc = localStorage.getItem('montflix_mylist_secure');
      const decryptedList = Security.decrypt(savedListEnc);
      setMyList(decryptedList || []);
    }

    const loadContent = async () => {
      try {
        const [trend, pop, playing, up, rated] = await Promise.all([
          tmdbService.fetchMultiPages(page => tmdbService.getTrending(page), 5),
          tmdbService.fetchMultiPages(page => tmdbService.getPopular(page), 5),
          tmdbService.fetchMultiPages(page => tmdbService.getNowPlaying(page), 5),
          tmdbService.fetchMultiPages(page => tmdbService.getUpcoming(page), 3),
          tmdbService.fetchMultiPages(page => tmdbService.getTopRated(page), 3)
        ]);
        
        const newSections = {
          trending: trend, popular: pop, nowPlaying: playing, upcoming: up, topRated: rated
        };
        
        setSections(newSections);
        tmdbService.setCacheData(newSections);
      } catch (err) {
        console.error("Erro ao carregar conteúdo inicial", err);
      }
    };
    
    loadContent();
  }, []);

  // Busca debounced inteligente para carregar milhares de resultados em tempo real
  useEffect(() => {
    if (!searchQuery || searchQuery.trim().length < 2) {
      setSearchResults([]);
      return;
    }

    const delayDebounce = setTimeout(async () => {
      setSearchLoading(true);
      try {
        const results = await tmdbService.fetchMultiPages(page => tmdbService.search(searchQuery, page), 3);
        setSearchResults(results);
      } catch (e) {
        console.error("Search error:", e);
      } finally {
        setSearchLoading(false);
      }
    }, 400);

    return () => clearTimeout(delayDebounce);
  }, [searchQuery]);

  // Carregar filmes por gênero selecionado
  useEffect(() => {
    if (!selectedGenre) {
      setGenreMovies([]);
      setGenrePage(1);
      return;
    }

    const loadGenreMovies = async () => {
      setGenreLoading(true);
      try {
        const results = await tmdbService.discoverByGenre(selectedGenre.id, 1);
        setGenreMovies(results);
        setGenrePage(1);
      } catch (e) {
        console.error("Genre fetch error:", e);
      } finally {
        setGenreLoading(false);
      }
    };

    loadGenreMovies();
  }, [selectedGenre]);

  const loadMoreGenreMovies = async () => {
    if (!selectedGenre || genreLoading) return;
    setGenreLoading(true);
    try {
      const nextPage = genrePage + 1;
      const results = await tmdbService.discoverByGenre(selectedGenre.id, nextPage);
      setGenreMovies(prev => [...prev, ...results].filter((v, i, a) => a.findIndex(t => t.id === v.id) === i));
      setGenrePage(nextPage);
    } catch (e) {
      console.error("Load more genre error:", e);
    } finally {
      setGenreLoading(false);
    }
  };

  const toggleFavorite = (movie: Movie) => {
    let newList;
    const exists = myList.find(m => m.id === movie.id);
    if (exists) {
      newList = myList.filter(m => m.id !== movie.id);
      setToastMessage("Removido da lista");
    } else {
      newList = [...myList, movie];
      setToastMessage("Adicionado à sua lista!");
    }
    setMyList(newList);
    localStorage.setItem('montflix_mylist_secure', Security.encrypt(newList));

    if (currentUser && activeProfile) {
      const updatedProfile = { ...activeProfile, myList: newList };
      setActiveProfile(updatedProfile);
      localStorage.setItem('montflix_active_profile_secure', Security.encrypt(updatedProfile));

      const storageKey = `montflix_profiles_${currentUser.email.toLowerCase().trim()}`;
      const savedEnc = localStorage.getItem(storageKey);
      if (savedEnc) {
        try {
          const decrypted = Security.decrypt(savedEnc) as UserProfile[];
          if (Array.isArray(decrypted)) {
            const updatedProfiles = decrypted.map(p => p.id === activeProfile.id ? updatedProfile : p);
            localStorage.setItem(storageKey, Security.encrypt(updatedProfiles));
          }
        } catch (err) {
          console.error("Error syncing favorites to profiles", err);
        }
      }
    }
  };

  const handleLogin = (authData: { email: string; avatar: string | null }) => {
    const emailLower = authData.email ? authData.email.toLowerCase().trim() : '';
    const hasPremium = emailLower === 'meudrivu@gmail.com' || emailLower === 'meudrivu@gmail.coml';
    
    const userKey = `montflix_user_record_${emailLower}`;
    const savedUserEnc = localStorage.getItem(userKey);
    let user;
    
    if (savedUserEnc) {
      try {
        user = Security.decrypt(savedUserEnc);
      } catch (e) {
        console.error("Error decrypting user record", e);
      }
    }
    
    if (!user) {
      user = { 
        id: crypto.randomUUID(), 
        email: authData.email, 
        name: authData.email.split('@')[0], 
        avatar: authData.avatar, 
        xp: 150,
        plan: hasPremium ? 'premium' : null 
      };
      localStorage.setItem(userKey, Security.encrypt(user));
    } else {
      if (hasPremium) {
        user.plan = 'premium';
      }
    }
    
    setCurrentUser(user);
    localStorage.setItem('montflix_session_secure', Security.encrypt(user));
  };

  const handlePlanSelection = (plan: 'essencial' | 'padrao' | 'premium', fullName?: string, cpf?: string) => {
    if (currentUser) {
      const updatedUser = { 
        ...currentUser, 
        plan,
        name: fullName || currentUser.name,
        cpf: cpf || currentUser.cpf
      };
      setCurrentUser(updatedUser);
      localStorage.setItem('montflix_session_secure', Security.encrypt(updatedUser));
      localStorage.setItem(`montflix_user_record_${currentUser.email.toLowerCase().trim()}`, Security.encrypt(updatedUser));
      setToastMessage(`Plano ${plan.toUpperCase()} ativado!`);
    }
  };

  const handleUpdateAvatar = (newAvatar: string) => {
    if (currentUser) {
      const updatedUser = { ...currentUser, avatar: newAvatar };
      setCurrentUser(updatedUser);
      localStorage.setItem('montflix_session_secure', Security.encrypt(updatedUser));
      localStorage.setItem(`montflix_user_record_${currentUser.email.toLowerCase().trim()}`, Security.encrypt(updatedUser));
    }
    if (currentUser && activeProfile) {
      const updatedProfile = { ...activeProfile, avatar: newAvatar };
      setActiveProfile(updatedProfile);
      localStorage.setItem('montflix_active_profile_secure', Security.encrypt(updatedProfile));

      const storageKey = `montflix_profiles_${currentUser.email.toLowerCase().trim()}`;
      const savedEnc = localStorage.getItem(storageKey);
      if (savedEnc) {
        try {
          const decrypted = Security.decrypt(savedEnc) as UserProfile[];
          if (Array.isArray(decrypted)) {
            const updatedProfiles = decrypted.map(p => p.id === activeProfile.id ? updatedProfile : p);
            localStorage.setItem(storageKey, Security.encrypt(updatedProfiles));
          }
        } catch (err) {
          console.error("Error updating avatar in profiles array", err);
        }
      }
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('montflix_session_secure');
    localStorage.removeItem('montflix_active_profile_secure');
    setCurrentUser(null);
    setActiveProfile(null);
  };

  if (!currentUser) return <AuthScreen onLogin={handleLogin} onStartPairing={() => {}} />;

  if (!currentUser.plan) {
    return (
      <PlanSelection 
        onSelectPlan={handlePlanSelection} 
        userEmail={currentUser.email} 
        onLogout={handleLogout} 
      />
    );
  }

  if (!activeProfile) {
    return (
      <ProfileSelection
        userEmail={currentUser.email}
        onSelectProfile={(profile) => {
          setActiveProfile(profile);
          setMyList(profile.myList || []);
          localStorage.setItem('montflix_active_profile_secure', Security.encrypt(profile));
        }}
        onLogout={handleLogout}
      />
    );
  }

  return (
    <div className={`min-h-screen bg-[#050505] text-white selection:bg-[#00D1FF] selection:text-black font-sans transition-colors duration-1000 ${currentView === 'iptv' ? 'selection:bg-[#00D1FF]' : ''}`}>
      <Navbar 
        onSearchChange={setSearchQuery} 
        onOpenSettings={() => setIsSettingsOpen(true)}
        userAvatar={activeProfile?.avatar || currentUser.avatar} 
        currentLang={language}
        currentView={currentView}
        onViewChange={setCurrentView}
        currentUserEmail={currentUser.email}
      />
      
      <main className="pb-40">
        {currentView === 'iptv' ? (
          <IPTVView />
        ) : currentView === 'favorites' ? (
          <div className="px-6 md:px-14 lg:px-24 pt-48 animate-in fade-in">
            <div className="flex items-center gap-4 mb-10">
              <div className="w-1.5 h-8 bg-[#00D1FF] rounded-full animate-pulse" />
              <h2 className="text-xl md:text-3xl font-black text-white uppercase tracking-tighter">
                ⭐ Sua Lista / Favoritos
              </h2>
            </div>
            {myList.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6 md:gap-8">
                {myList.map((movie) => (
                  <MovieCard 
                    key={movie.id} 
                    movie={movie} 
                    onSelect={setDetailMovie} 
                    onToggleFavorite={() => toggleFavorite(movie)}
                    isFavorite={true}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-24 bg-zinc-950/20 border border-white/5 rounded-[2.5rem] p-8 space-y-3 max-w-xl mx-auto">
                <p className="text-white/40 text-lg font-black uppercase tracking-widest">Sua lista está vazia</p>
                <p className="text-white/20 text-xs leading-relaxed">
                  Adicione filmes clicando no botão "Adicionar à minha Lista" nos detalhes de qualquer título.
                </p>
              </div>
            )}
          </div>
        ) : searchQuery.length > 0 ? (
          <div className="px-6 md:px-14 lg:px-24 pt-48 animate-in fade-in">
            {searchLoading ? (
              <div className="flex flex-col items-center justify-center py-24 gap-4">
                <div className="w-12 h-12 border-4 border-[#00D1FF] border-t-transparent rounded-full animate-spin shadow-[0_0_15px_#00D1FF]" />
                <p className="text-white/40 text-sm font-black uppercase tracking-widest animate-pulse">Buscando em milhares de servidores...</p>
              </div>
            ) : searchQuery.length > 0 && searchResults.length > 0 ? (
              <div>
                <h2 className="text-xl md:text-3xl font-black text-white uppercase tracking-tighter mb-10">
                  🔍 Resultados para: <span className="text-[#00D1FF]">{searchQuery}</span>
                </h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6 md:gap-8">
                  {searchResults.map((movie) => (
                    <MovieCard 
                      key={movie.id} 
                      movie={movie} 
                      onSelect={setDetailMovie} 
                      onToggleFavorite={() => toggleFavorite(movie)}
                      isFavorite={!!myList.find(f => f.id === movie.id)}
                    />
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-24">
                <p className="text-white/40 text-lg font-black uppercase tracking-widest">Nenhum filme encontrado para "{searchQuery}"</p>
                <p className="text-white/20 text-xs mt-2">Tente pesquisar com outras palavras-chave ou confira os recomendados.</p>
              </div>
            )}
          </div>
        ) : (
          <div className="animate-in fade-in">
            <Hero movies={sections.trending.slice(0,5)} onWatchNow={setDetailMovie} currentLang={language} />
            
            <div className="relative z-20 -mt-48 space-y-32">
              {/* SELETOR DE GÊNEROS ULTRA-FLUIDO */}
              <div className="px-6 md:px-14 lg:px-24">
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-4">
                    <div className="w-1.5 h-8 bg-[#00D1FF] rounded-full" />
                    <h2 className="text-xl md:text-3xl font-black text-white uppercase tracking-tighter">
                      Navegar por Gênero
                    </h2>
                  </div>
                  {selectedGenre && (
                    <button 
                      onClick={() => setSelectedGenre(null)}
                      className="text-xs font-black uppercase tracking-widest text-[#00D1FF] hover:underline"
                    >
                      Mostrar Todos
                    </button>
                  )}
                </div>
                <div className="flex gap-4 overflow-x-auto scrollbar-hide pb-4">
                  <button
                    onClick={() => setSelectedGenre(null)}
                    className={`px-6 py-3 rounded-full text-xs font-black uppercase tracking-wider border transition-all shrink-0 ${
                      !selectedGenre 
                        ? 'bg-[#00D1FF] border-[#00D1FF] text-black shadow-[0_0_20px_rgba(0,209,255,0.3)] font-black scale-105' 
                        : 'bg-zinc-900/80 border-white/10 text-white hover:border-white/30'
                    }`}
                  >
                    🏠 Todos os Filmes
                  </button>
                  {GENRES.map((g) => (
                    <button
                      key={g.id}
                      onClick={() => setSelectedGenre(g)}
                      className={`px-6 py-3 rounded-full text-xs font-black uppercase tracking-wider border transition-all shrink-0 ${
                        selectedGenre?.id === g.id
                          ? 'bg-[#00D1FF] border-[#00D1FF] text-black shadow-[0_0_20px_rgba(0,209,255,0.3)] font-black scale-105' 
                          : 'bg-zinc-900/80 border-white/10 text-white hover:border-white/30'
                      }`}
                    >
                      {g.name}
                    </button>
                  ))}
                </div>
              </div>

              {selectedGenre ? (
                <div className="px-6 md:px-14 lg:px-24">
                  <h3 className="text-xl md:text-3xl font-black text-white uppercase tracking-tighter mb-8">
                    Catálogo: <span className="text-[#00D1FF]">{selectedGenre.name}</span>
                  </h3>
                  
                  {genreLoading && genreMovies.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-24 gap-4">
                      <div className="w-12 h-12 border-4 border-[#00D1FF] border-t-transparent rounded-full animate-spin shadow-[0_0_15px_#00D1FF]" />
                    </div>
                  ) : (
                    <div>
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6 md:gap-8">
                        {genreMovies.map((movie) => (
                          <MovieCard 
                            key={movie.id} 
                            movie={movie} 
                            onSelect={setDetailMovie} 
                            onToggleFavorite={() => toggleFavorite(movie)}
                            isFavorite={!!myList.find(f => f.id === movie.id)}
                          />
                        ))}
                      </div>
                      
                      <div className="flex justify-center mt-16">
                        <button
                          onClick={loadMoreGenreMovies}
                          disabled={genreLoading}
                          className="px-10 py-4 bg-white/5 border border-white/10 hover:border-[#00D1FF]/50 hover:bg-[#00D1FF]/5 text-white hover:text-[#00D1FF] rounded-full font-black text-xs uppercase tracking-widest transition-all duration-300 disabled:opacity-50"
                        >
                          {genreLoading ? 'Carregando mais filmes...' : 'Ver Mais Filmes'}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <>
                  {myList.length > 0 && (
                    <MovieRow title="⭐ Sua Lista" movies={myList} onSelect={setDetailMovie} onToggleFavorite={toggleFavorite} isFavoriteList={true} />
                  )}
                  
                  <MovieRow title="🔥 Filmes em Alta" movies={sections.trending} onSelect={setDetailMovie} onToggleFavorite={toggleFavorite} favorites={myList} />
                  <MovieRow title="🎬 Mais Populares" movies={sections.popular} onSelect={setDetailMovie} onToggleFavorite={toggleFavorite} favorites={myList} />
                  <MovieRow title="🍿 Agora no Cinema" movies={sections.nowPlaying} onSelect={setDetailMovie} onToggleFavorite={toggleFavorite} favorites={myList} />
                </>
              )}
            </div>
          </div>
        )}
      </main>

      <SettingsModal 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)} 
        user={{ ...currentUser, name: activeProfile?.name || currentUser.name, avatar: activeProfile?.avatar || currentUser.avatar }} 
        onUpdateAvatar={handleUpdateAvatar} 
        onLogout={handleLogout} 
        currentLang={language} setLanguage={setLanguage} onShowToast={setToastMessage}
        onSwitchProfile={() => { localStorage.removeItem('montflix_active_profile_secure'); setActiveProfile(null); }}
      />
      
      {detailMovie && (
        <MovieDetailModal 
          movie={detailMovie} 
          onClose={() => setDetailMovie(null)} 
          onWatchFullMovie={(movie) => {
            setDetailMovie(null);
            setActiveMovie(movie);
          }}
          userPlan={currentUser.plan}
          myList={myList}
          onToggleFavorite={toggleFavorite}
        />
      )}
      {activeMovie && <VideoPlayer movie={activeMovie} userPlan={currentUser.plan} onClose={() => setActiveMovie(null)} />}
      {activeChannel && <IPTVPlayer channel={activeChannel} onClose={() => setActiveChannel(null)} />}
      
      {toastMessage && <NotificationToast message={toastMessage} onClose={() => setToastMessage(null)} />}
 
      <BottomNav 
        currentView={currentView}
        onViewChange={setCurrentView}
        onOpenSettings={() => setIsSettingsOpen(true)}
        userAvatar={activeProfile?.avatar || currentUser.avatar}
      />
    </div>
  );
};

export default App;
